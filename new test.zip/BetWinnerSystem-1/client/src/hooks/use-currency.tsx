import { createContext, ReactNode, useContext, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CurrencyRates {
  usdtToBdt: number;
}

interface TopUpRequest {
  amount: number;
  currency: "USDT";
  paymentMethod: "binance_pay" | "custom_usdt";
  walletAddress?: string;
}

interface CurrencyContextType {
  rates: CurrencyRates;
  isLoadingRates: boolean;
  topUpMutation: ReturnType<typeof useMutation<any, Error, TopUpRequest>>;
  convertUsdtToBdt: (amount: number) => number;
}

const CurrencyContext = createContext<CurrencyContextType | null>(null);

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [rates, setRates] = useState<CurrencyRates>({ usdtToBdt: 125.45 });

  const { isLoading: isLoadingRates } = useQuery({
    queryKey: ["/api/rates"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    onSuccess: (data) => {
      if (data) {
        setRates({ usdtToBdt: data.usdtToBdt });
      }
    },
  });

  const topUpMutation = useMutation({
    mutationFn: async (request: TopUpRequest) => {
      const res = await apiRequest("POST", "/api/topup", request);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Top-up request submitted",
        description: "Your request has been submitted and is pending approval.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Top-up request failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const convertUsdtToBdt = (amount: number): number => {
    return amount * rates.usdtToBdt;
  };

  return (
    <CurrencyContext.Provider
      value={{
        rates,
        isLoadingRates,
        topUpMutation,
        convertUsdtToBdt,
      }}
    >
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error("useCurrency must be used within a CurrencyProvider");
  }
  return context;
}
