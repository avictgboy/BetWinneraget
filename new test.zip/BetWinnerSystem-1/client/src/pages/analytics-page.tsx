import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/layouts/app-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Loader2, Calendar } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { 
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from "recharts";

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState("week");
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch analytics data
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['/api/admin/analytics', timeRange],
    queryFn: async () => {
      // This would call the real API in a production environment
      // For now, return some mock data for visualization
      return {
        transactions: {
          deposits: [
            { date: '04/24', count: 12, amount: 10500 },
            { date: '04/25', count: 15, amount: 12800 },
            { date: '04/26', count: 10, amount: 9300 },
            { date: '04/27', count: 14, amount: 11600 },
            { date: '04/28', count: 18, amount: 15700 },
            { date: '04/29', count: 20, amount: 16900 },
            { date: '04/30', count: 16, amount: 13500 },
          ],
          withdrawals: [
            { date: '04/24', count: 8, amount: 7200 },
            { date: '04/25', count: 10, amount: 8900 },
            { date: '04/26', count: 7, amount: 6300 },
            { date: '04/27', count: 9, amount: 7800 },
            { date: '04/28', count: 11, amount: 9500 },
            { date: '04/29', count: 13, amount: 11200 },
            { date: '04/30', count: 10, amount: 8700 },
          ]
        },
        users: {
          newUsers: [
            { date: '04/24', count: 5 },
            { date: '04/25', count: 7 },
            { date: '04/26', count: 3 },
            { date: '04/27', count: 6 },
            { date: '04/28', count: 9 },
            { date: '04/29', count: 8 },
            { date: '04/30', count: 11 },
          ],
          activeUsers: [
            { date: '04/24', count: 28 },
            { date: '04/25', count: 32 },
            { date: '04/26', count: 30 },
            { date: '04/27', count: 35 },
            { date: '04/28', count: 42 },
            { date: '04/29', count: 45 },
            { date: '04/30', count: 50 },
          ]
        },
        summary: {
          totalDeposits: 90300,
          totalWithdrawals: 59600,
          netDeposits: 30700,
          totalUsers: 85,
          totalAgents: 12,
          totalPlayers: 73
        }
      };
    }
  });

  const handleTimeRangeChange = (value: string) => {
    setTimeRange(value);
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-BD', {
      style: 'currency',
      currency: 'BDT',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex justify-center items-center h-[50vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Loading analytics data...</span>
        </div>
      </AppLayout>
    );
  }

  if (error) {
    return (
      <AppLayout>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-3xl font-bold tracking-tight">Analytics</h2>
          </div>
          <Card>
            <CardHeader>
              <CardTitle className="text-destructive">Error</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Failed to load analytics data. Please try again later.</p>
              <Button onClick={() => refetch()} className="mt-4">Retry</Button>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Analytics</h2>
            <p className="text-muted-foreground">
              Platform performance and usage statistics
            </p>
          </div>
          <div className="flex items-center gap-4">
            <Select 
              defaultValue={timeRange} 
              onValueChange={handleTimeRangeChange}
            >
              <SelectTrigger className="w-[180px]">
                <Calendar className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Select time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="day">Today</SelectItem>
                <SelectItem value="week">Last 7 days</SelectItem>
                <SelectItem value="month">Last 30 days</SelectItem>
                <SelectItem value="quarter">Last 3 months</SelectItem>
                <SelectItem value="year">Last 12 months</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={() => refetch()}>
              Refresh
            </Button>
          </div>
        </div>

        {data && (
          <>
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-medium">Total Deposits</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(data.summary.totalDeposits)}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Net: {formatCurrency(data.summary.netDeposits)}
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-medium">Total Withdrawals</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(data.summary.totalWithdrawals)}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-medium">Active Users</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{data.summary.totalUsers}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Agents: {data.summary.totalAgents} | Players: {data.summary.totalPlayers}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="transactions">Transactions</TabsTrigger>
                <TabsTrigger value="users">Users</TabsTrigger>
              </TabsList>

              <TabsContent value="overview">
                <Card>
                  <CardHeader>
                    <CardTitle>Transaction Overview</CardTitle>
                    <CardDescription>
                      Deposit and withdrawal activities
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={data.transactions.deposits}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip formatter={(value) => formatCurrency(value as number)} />
                        <Legend />
                        <Bar name="Deposits" dataKey="amount" fill="#4f46e5" />
                        <Bar name="Withdrawals" dataKey={(_, index) => data.transactions.withdrawals[index].amount} fill="#f43f5e" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="transactions">
                <Card>
                  <CardHeader>
                    <CardTitle>Transaction Volume</CardTitle>
                    <CardDescription>
                      Number of deposits and withdrawals
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" allowDuplicatedCategory={false} />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line 
                          name="Deposits" 
                          data={data.transactions.deposits} 
                          dataKey="count" 
                          stroke="#4f46e5" 
                          strokeWidth={2} 
                          dot={{ r: 4 }} 
                        />
                        <Line 
                          name="Withdrawals" 
                          data={data.transactions.withdrawals} 
                          dataKey="count" 
                          stroke="#f43f5e" 
                          strokeWidth={2} 
                          dot={{ r: 4 }} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="users">
                <Card>
                  <CardHeader>
                    <CardTitle>User Activity</CardTitle>
                    <CardDescription>
                      New and active users
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" allowDuplicatedCategory={false} />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line 
                          name="New Users" 
                          data={data.users.newUsers} 
                          dataKey="count" 
                          stroke="#f59e0b" 
                          strokeWidth={2} 
                          dot={{ r: 4 }} 
                        />
                        <Line 
                          name="Active Users" 
                          data={data.users.activeUsers} 
                          dataKey="count" 
                          stroke="#10b981" 
                          strokeWidth={2} 
                          dot={{ r: 4 }} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </AppLayout>
  );
}