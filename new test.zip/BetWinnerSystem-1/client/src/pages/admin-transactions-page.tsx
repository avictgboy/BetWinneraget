import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { AppLayout } from "@/layouts/app-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Loader2, CheckCircle, XCircle, Copy, Check } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface PendingTransaction {
  id: number;
  type: string;
  playerId: string;
  amount: number;
  paymentCode?: string;
  date: string;
  time: string;
  status: string;
  agentId: number;
  agentUsername: string;
  commissionAmount?: number;
}

// Copyable text component with 1-click copy functionality
function CopyableText({ text, label }: { text: string, label: string }) {
  const [copied, setCopied] = useState(false);
  
  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  return (
    <TooltipProvider>
      <Tooltip>
        <div className="flex items-center">
          <span className="mr-2">{text}</span>
          <TooltipTrigger asChild>
            <button 
              onClick={handleCopy} 
              className="text-muted-foreground hover:text-primary focus:outline-none"
              aria-label={`Copy ${label}`}
            >
              {copied ? (
                <Check className="h-4 w-4 text-green-500" />
              ) : (
                <Copy className="h-4 w-4" />
              )}
            </button>
          </TooltipTrigger>
        </div>
        <TooltipContent>
          {copied ? "Copied!" : `Copy ${label}`}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

export default function AdminTransactionsPage() {
  const { toast } = useToast();
  const [selectedTab, setSelectedTab] = useState("pending");
  const [selectedTransaction, setSelectedTransaction] = useState<PendingTransaction | null>(null);
  const [isApproveDialogOpen, setIsApproveDialogOpen] = useState(false);
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  const [reason, setReason] = useState("");

  // Fetch pending transactions
  const { data: pendingTransactions, isLoading, error, refetch } = useQuery({
    queryKey: ["/api/admin/transactions/pending"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/admin/transactions/pending");
      return await res.json() as PendingTransaction[];
    }
  });

  // Approve transaction mutation
  const approveMutation = useMutation({
    mutationFn: async ({ transactionId, reason }: { transactionId: number, reason: string }) => {
      const response = await apiRequest(
        "POST", 
        `/api/admin/transactions/${transactionId}/process`,
        { approve: true, reason }
      );
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Transaction Approved",
        description: "The transaction has been successfully approved.",
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/transactions/pending"] });
      setIsApproveDialogOpen(false);
      setSelectedTransaction(null);
      setReason("");
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to approve transaction: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // Reject transaction mutation
  const rejectMutation = useMutation({
    mutationFn: async ({ transactionId, reason }: { transactionId: number, reason: string }) => {
      const response = await apiRequest(
        "POST", 
        `/api/admin/transactions/${transactionId}/process`,
        { approve: false, reason }
      );
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Transaction Rejected",
        description: "The transaction has been successfully rejected.",
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/transactions/pending"] });
      setIsRejectDialogOpen(false);
      setSelectedTransaction(null);
      setReason("");
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to reject transaction: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  const handleApprove = (transaction: PendingTransaction) => {
    setSelectedTransaction(transaction);
    setIsApproveDialogOpen(true);
  };

  const handleReject = (transaction: PendingTransaction) => {
    setSelectedTransaction(transaction);
    setIsRejectDialogOpen(true);
  };

  const confirmApprove = () => {
    if (selectedTransaction) {
      approveMutation.mutate({ 
        transactionId: selectedTransaction.id,
        reason: reason || "Approved by admin"
      });
    }
  };

  const confirmReject = () => {
    if (selectedTransaction) {
      rejectMutation.mutate({ 
        transactionId: selectedTransaction.id,
        reason: reason || "Rejected by admin"
      });
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "pending": return "outline";
      case "approved": return "default"; // Changed from "success" to "default"
      case "rejected": return "destructive";
      default: return "secondary";
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'BDT',
      minimumFractionDigits: 2
    }).format(amount);
  };

  // Render loading state
  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Loading transactions...</span>
        </div>
      </AppLayout>
    );
  }

  // Render error state
  if (error) {
    return (
      <AppLayout>
        <Card>
          <CardHeader>
            <CardTitle className="text-destructive">Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Failed to load transactions. Please try again later.</p>
            <Button onClick={() => refetch()} className="mt-4">Retry</Button>
          </CardContent>
        </Card>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container mx-auto py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Transaction Management</h1>
          <Button onClick={() => refetch()} variant="outline">
            Refresh Transactions
          </Button>
        </div>

        <Tabs defaultValue="pending" value={selectedTab} onValueChange={setSelectedTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="pending">Pending Transactions</TabsTrigger>
            <TabsTrigger value="all">All Transactions</TabsTrigger>
          </TabsList>
          
          <TabsContent value="pending">
            <Card>
              <CardHeader>
                <CardTitle>Pending Transactions</CardTitle>
                <CardDescription>
                  Transactions waiting for approval or rejection
                </CardDescription>
              </CardHeader>
              <CardContent>
                {!pendingTransactions || pendingTransactions.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No pending transactions found.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-3 px-4">ID</th>
                          <th className="text-left py-3 px-4">Type</th>
                          <th className="text-left py-3 px-4">Player ID</th>
                          <th className="text-left py-3 px-4">Agent</th>
                          <th className="text-left py-3 px-4">Amount</th>
                          <th className="text-left py-3 px-4">Payment Code</th>
                          <th className="text-left py-3 px-4">Date</th>
                          <th className="text-left py-3 px-4">Status</th>
                          <th className="text-left py-3 px-4">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {pendingTransactions.map(transaction => (
                          <tr key={transaction.id} className="border-b hover:bg-muted/50">
                            <td className="py-3 px-4">{transaction.id}</td>
                            <td className="py-3 px-4 capitalize">{transaction.type}</td>
                            <td className="py-3 px-4">
                              <CopyableText text={transaction.playerId} label="Player ID" />
                            </td>
                            <td className="py-3 px-4">{transaction.agentUsername}</td>
                            <td className="py-3 px-4">{formatCurrency(transaction.amount)}</td>
                            <td className="py-3 px-4">
                              {transaction.type === 'withdrawal' && transaction.paymentCode ? (
                                <CopyableText text={transaction.paymentCode} label="Payment Code" />
                              ) : '-'}
                            </td>
                            <td className="py-3 px-4">{transaction.date} {transaction.time}</td>
                            <td className="py-3 px-4">
                              <Badge variant={getStatusBadgeVariant(transaction.status)}>
                                {transaction.status}
                              </Badge>
                            </td>
                            <td className="py-3 px-4">
                              <div className="flex space-x-2">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  className="bg-green-50 hover:bg-green-100 text-green-700 hover:text-green-800 border-green-200"
                                  onClick={() => handleApprove(transaction)}
                                  disabled={approveMutation.isPending || rejectMutation.isPending}
                                >
                                  {approveMutation.isPending && selectedTransaction?.id === transaction.id ? (
                                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                                  ) : (
                                    <CheckCircle className="h-4 w-4 mr-1" />
                                  )}
                                  Approve
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  className="bg-red-50 hover:bg-red-100 text-red-700 hover:text-red-800 border-red-200"
                                  onClick={() => handleReject(transaction)}
                                  disabled={approveMutation.isPending || rejectMutation.isPending}
                                >
                                  {rejectMutation.isPending && selectedTransaction?.id === transaction.id ? (
                                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                                  ) : (
                                    <XCircle className="h-4 w-4 mr-1" />
                                  )}
                                  Reject
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="all">
            <Card>
              <CardHeader>
                <CardTitle>All Transactions</CardTitle>
                <CardDescription>
                  Complete transaction history
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-muted-foreground">
                  This tab will show all transactions (feature coming soon).
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Approve Dialog */}
      <Dialog open={isApproveDialogOpen} onOpenChange={setIsApproveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve Transaction</DialogTitle>
            <DialogDescription>
              Are you sure you want to approve this transaction?
            </DialogDescription>
          </DialogHeader>
          
          {selectedTransaction && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Transaction ID</p>
                  <p>{selectedTransaction.id}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Type</p>
                  <p className="capitalize">{selectedTransaction.type}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Player ID</p>
                  <div className="mt-1">
                    <CopyableText text={selectedTransaction.playerId} label="Player ID" />
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Amount</p>
                  <p>{formatCurrency(selectedTransaction.amount)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Agent</p>
                  <p>{selectedTransaction.agentUsername}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Date</p>
                  <p>{selectedTransaction.date}</p>
                </div>
                {selectedTransaction.type === 'withdrawal' && selectedTransaction.paymentCode && (
                  <div className="col-span-2">
                    <p className="text-sm font-medium text-muted-foreground">Payment Code</p>
                    <div className="mt-1">
                      <CopyableText text={selectedTransaction.paymentCode} label="Payment Code" />
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-2">
                <Label htmlFor="approve-reason">Approval Reason (Optional)</Label>
                <Textarea
                  id="approve-reason"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Enter a reason for approving this transaction"
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsApproveDialogOpen(false)}>Cancel</Button>
            <Button 
              variant="default" 
              onClick={confirmApprove}
              disabled={approveMutation.isPending}
            >
              {approveMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirm Approval
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Transaction</DialogTitle>
            <DialogDescription>
              Are you sure you want to reject this transaction?
            </DialogDescription>
          </DialogHeader>
          
          {selectedTransaction && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Transaction ID</p>
                  <p>{selectedTransaction.id}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Type</p>
                  <p className="capitalize">{selectedTransaction.type}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Player ID</p>
                  <div className="mt-1">
                    <CopyableText text={selectedTransaction.playerId} label="Player ID" />
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Amount</p>
                  <p>{formatCurrency(selectedTransaction.amount)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Agent</p>
                  <p>{selectedTransaction.agentUsername}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Date</p>
                  <p>{selectedTransaction.date}</p>
                </div>
                {selectedTransaction.type === 'withdrawal' && selectedTransaction.paymentCode && (
                  <div className="col-span-2">
                    <p className="text-sm font-medium text-muted-foreground">Payment Code</p>
                    <div className="mt-1">
                      <CopyableText text={selectedTransaction.paymentCode} label="Payment Code" />
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-2">
                <Label htmlFor="reject-reason">Rejection Reason</Label>
                <Textarea
                  id="reject-reason"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Enter a reason for rejecting this transaction"
                  className="mt-1"
                  required
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRejectDialogOpen(false)}>Cancel</Button>
            <Button 
              variant="destructive" 
              onClick={confirmReject}
              disabled={rejectMutation.isPending || !reason.trim()}
            >
              {rejectMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirm Rejection
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}