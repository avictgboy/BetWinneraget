import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "../lib/apiRequest";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { AppLayout } from "@/layouts/app-layout";
import { ExtendedRemittanceTransaction, RecipientAdditionalInfo } from "@shared/schema";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { CopyButton } from "@/components/ui/copy-button";
import {
  Settings,
  FilePenLine,
  Trash2,
  CheckCircle,
  XCircle,
  PlusCircle,
  BarChart3,
  Percent,
  DollarSign,
  CircleDollarSign,
  Clock,
  Copy,
  Check,
} from "lucide-react";

// Schema for fee creation/editing
const feeSchema = z.object({
  name: z.string().min(3, "Name is required"),
  description: z.string().optional(),
  channel: z.enum(["npsb_bank", "bkash", "nagad", "rocket"], {
    required_error: "Please select a channel",
  }),
  feeType: z.enum(["flat", "percentage", "hybrid"], {
    required_error: "Please select a fee type",
  }),
  flatFee: z.coerce.number().optional(),
  percentageFee: z.coerce.number().optional(),
  minAmount: z.coerce.number().optional(),
  maxAmount: z.coerce.number().nullable().optional(),
  active: z.boolean().default(true),
}).refine(
  (data) => {
    if (data.feeType === "flat" && (data.flatFee === undefined || data.flatFee < 0)) {
      return false;
    }
    return true;
  },
  {
    message: "Flat fee is required for fee type 'flat'",
    path: ["flatFee"],
  }
).refine(
  (data) => {
    if (data.feeType === "percentage" && (data.percentageFee === undefined || data.percentageFee < 0)) {
      return false;
    }
    return true;
  },
  {
    message: "Percentage fee is required for fee type 'percentage'",
    path: ["percentageFee"],
  }
).refine(
  (data) => {
    if (data.feeType === "hybrid" && (
      data.flatFee === undefined || data.flatFee < 0 ||
      data.percentageFee === undefined || data.percentageFee < 0
    )) {
      return false;
    }
    return true;
  },
  {
    message: "Both flat and percentage fees are required for fee type 'hybrid'",
    path: ["feeType"],
  }
);

// Schema for transaction processing
const processTransactionSchema = z.object({
  approve: z.boolean(),
  reason: z.string().optional(),
  transactionNumber: z.string().optional(),
});

type FeeFormValues = z.infer<typeof feeSchema>;
type ProcessTransactionValues = z.infer<typeof processTransactionSchema>;

function AdminRemittancePage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("fees");
  const [editingFee, setEditingFee] = useState<any | null>(null);
  const [isAddFeeDialogOpen, setIsAddFeeDialogOpen] = useState(false);
  const [processingTransaction, setProcessingTransaction] = useState<ExtendedRemittanceTransaction | null>(null);
  const [isProcessingDialogOpen, setIsProcessingDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);

  // Form setup for fee management
  const feeForm = useForm<FeeFormValues>({
    resolver: zodResolver(feeSchema),
    defaultValues: {
      name: "",
      description: "",
      flatFee: undefined,
      percentageFee: undefined,
      minAmount: undefined,
      maxAmount: undefined,
      active: true,
    },
  });

  // Form setup for transaction processing
  const processForm = useForm<ProcessTransactionValues>({
    resolver: zodResolver(processTransactionSchema),
    defaultValues: {
      approve: true,
      reason: "",
      transactionNumber: "",
    },
  });

  // Fetch remittance fees
  const { data: fees = [], refetch: refetchFees } = useQuery({
    queryKey: ["admin-remittance-fees"],
    queryFn: async () => {
      const response = await apiRequest<any[]>("/api/admin/remittance-fees");
      return response;
    },
  });

  // Fetch pending remittance transactions
  const { data: pendingTransactions = [], refetch: refetchPendingTransactions } = useQuery({
    queryKey: ["admin-pending-remittance-transactions"],
    queryFn: async () => {
      const response = await apiRequest<ExtendedRemittanceTransaction[]>("/api/admin/remittance/pending");
      return response;
    },
  });

  // Create or update fee
  const feeMutation = useMutation({
    mutationFn: async (values: FeeFormValues) => {
      if (isEditMode && editingFee) {
        return await apiRequest(`/api/admin/remittance-fees/${editingFee.id}`, "PUT", values);
      } else {
        return await apiRequest("/api/admin/remittance-fees", "POST", values);
      }
    },
    onSuccess: () => {
      toast({
        title: isEditMode ? "Fee Updated" : "Fee Created",
        description: isEditMode
          ? "The remittance fee has been updated successfully."
          : "A new remittance fee has been created.",
      });
      feeForm.reset();
      setIsAddFeeDialogOpen(false);
      setEditingFee(null);
      setIsEditMode(false);
      refetchFees();
    },
    onError: (error: any) => {
      toast({
        title: isEditMode ? "Failed to update fee" : "Failed to create fee",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    },
  });

  // Delete fee
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/admin/remittance-fees/${id}`, "DELETE");
    },
    onSuccess: () => {
      toast({
        title: "Fee Deleted",
        description: "The remittance fee has been deleted successfully.",
      });
      refetchFees();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to delete fee",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    },
  });

  // Process remittance transaction
  const processTransactionMutation = useMutation({
    mutationFn: async ({ transactionId, data }: { transactionId: number; data: ProcessTransactionValues }) => {
      return await apiRequest(`/api/admin/remittance/${transactionId}/process`, "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Transaction Processed",
        description: processForm.getValues("approve")
          ? "The remittance transaction has been approved."
          : "The remittance transaction has been rejected.",
      });
      processForm.reset({ approve: true, reason: "", transactionNumber: "" });
      setIsProcessingDialogOpen(false);
      setProcessingTransaction(null);
      refetchPendingTransactions();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to process transaction",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    },
  });

  const onSubmitFee = (values: FeeFormValues) => {
    feeMutation.mutate(values);
  };

  const onSubmitProcessTransaction = (values: ProcessTransactionValues) => {
    if (processingTransaction) {
      processTransactionMutation.mutate({
        transactionId: processingTransaction.id,
        data: values,
      });
    }
  };

  const handleEditFee = (fee: any) => {
    setEditingFee(fee);
    setIsEditMode(true);
    feeForm.reset({
      name: fee.name || "",
      description: fee.description || "",
      channel: fee.channel,
      feeType: fee.feeType,
      flatFee: fee.flatFee ? Number(fee.flatFee) : undefined,
      percentageFee: fee.percentageFee ? Number(fee.percentageFee) : undefined,
      minAmount: fee.minAmount ? Number(fee.minAmount) : undefined,
      maxAmount: fee.maxAmount ? Number(fee.maxAmount) : null,
      active: fee.active,
    });
    setIsAddFeeDialogOpen(true);
  };

  const handleAddNewFee = () => {
    setIsEditMode(false);
    setEditingFee(null);
    feeForm.reset({
      name: "",
      description: "",
      channel: undefined,
      feeType: undefined,
      flatFee: undefined,
      percentageFee: undefined,
      minAmount: undefined,
      maxAmount: undefined,
      active: true,
    });
    setIsAddFeeDialogOpen(true);
  };

  const handleDeleteFee = (id: number) => {
    if (window.confirm("Are you sure you want to delete this fee?")) {
      deleteMutation.mutate(id);
    }
  };

  const handleProcessTransaction = (transaction: ExtendedRemittanceTransaction) => {
    setProcessingTransaction(transaction);
    processForm.reset({
      approve: true,
      reason: "",
      transactionNumber: "",
    });
    setIsProcessingDialogOpen(true);
  };

  // Format date
  const formatDate = (dateValue: string | Date) => {
    const date = typeof dateValue === 'string' ? new Date(dateValue) : dateValue;
    return date.toLocaleDateString() + " " + date.toLocaleTimeString();
  };

  // Helper to get channel name
  const getChannelName = (channel: string) => {
    switch (channel) {
      case "npsb_bank": return "NPSB Bank";
      case "bkash": return "bKash";
      case "nagad": return "Nagad";
      case "rocket": return "Rocket";
      default: return channel;
    }
  };

  return (
    <AppLayout>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Remittance Admin</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="fees">
            <Settings className="h-4 w-4 mr-2" />
            Fee Configuration
          </TabsTrigger>
          <TabsTrigger value="transactions">
            <FilePenLine className="h-4 w-4 mr-2" />
            Pending Transactions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="fees" className="space-y-6 mt-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Remittance Fees</h2>
            <Button onClick={handleAddNewFee}>
              <PlusCircle className="h-4 w-4 mr-2" />
              Add New Fee
            </Button>
          </div>

          <Card>
            <CardContent className="pt-6 px-0 sm:px-6">
              {/* Mobile view - Card-based layout */}
              <div className="block md:hidden space-y-4">
                {fees.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No fees configured yet. Click "Add New Fee" to create one.
                  </div>
                ) : (
                  fees.map((fee: {
                    id: number;
                    name: string;
                    description?: string;
                    channel: string;
                    feeType: "flat" | "percentage" | "hybrid";
                    flatFee: string | null;
                    percentageFee: string | null;
                    minAmount: string | null;
                    maxAmount: string | null;
                    active: boolean;
                  }) => (
                    <Card key={fee.id} className="rounded-md overflow-hidden border border-gray-200">
                      <CardHeader className="p-4 bg-slate-50 flex flex-row justify-between items-center">
                        <div>
                          <div className="font-medium">{fee.name}</div>
                          {fee.description && <div className="text-sm text-gray-500">{fee.description}</div>}
                        </div>
                        {fee.active ? (
                          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">
                            Active
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-300">
                            Inactive
                          </Badge>
                        )}
                      </CardHeader>
                      <CardContent className="p-4 grid grid-cols-2 gap-3">
                        <div>
                          <p className="text-xs text-gray-500">Channel</p>
                          <p className="text-sm font-medium">{getChannelName(fee.channel)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Fee Type</p>
                          <p className="text-sm font-medium capitalize">{fee.feeType}</p>
                        </div>
                        <div className="col-span-2 border-t pt-2 mt-1">
                          <p className="text-xs text-gray-500">Fee Details</p>
                          <div>
                            {fee.feeType === "flat" && fee.flatFee && (
                              <p className="text-sm">Fixed fee: ৳ {Number(fee.flatFee).toFixed(2)}</p>
                            )}
                            {fee.feeType === "percentage" && fee.percentageFee && (
                              <p className="text-sm">{Number(fee.percentageFee).toFixed(2)}% of amount</p>
                            )}
                            {fee.feeType === "hybrid" && (
                              <div className="space-y-1">
                                {fee.flatFee && <p className="text-sm">Fixed: ৳ {Number(fee.flatFee).toFixed(2)}</p>}
                                {fee.percentageFee && <p className="text-sm">Plus {Number(fee.percentageFee).toFixed(2)}%</p>}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="col-span-2 border-t pt-2">
                          <p className="text-xs text-gray-500">Amount Range</p>
                          <div className="flex justify-between text-sm">
                            <div>
                              {fee.minAmount ? (
                                <span>From ৳ {Number(fee.minAmount).toFixed(2)}</span>
                              ) : (
                                <span>No lower limit</span>
                              )}
                            </div>
                            <div>
                              {fee.maxAmount ? (
                                <span>To ৳ {Number(fee.maxAmount).toFixed(2)}</span>
                              ) : (
                                <span>No upper limit</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="col-span-2 border-t pt-2 flex justify-between">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditFee(fee)}
                            className="flex items-center gap-1"
                          >
                            <FilePenLine className="h-4 w-4" />
                            <span>Edit</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteFee(fee.id)}
                            className="text-red-500 hover:text-red-700 hover:bg-red-50 flex items-center gap-1"
                          >
                            <Trash2 className="h-4 w-4" />
                            <span>Delete</span>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
              
              {/* Desktop view - Table layout */}
              <div className="hidden md:block">
                <Table>
                  <TableCaption>Remittance fee configuration</TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Channel</TableHead>
                      <TableHead>Fee Type</TableHead>
                      <TableHead>Fee Details</TableHead>
                      <TableHead>Amount Range</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {fees.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                          No fees configured yet. Click "Add New Fee" to create one.
                        </TableCell>
                      </TableRow>
                    ) : (
                      fees.map((fee: {
                        id: number;
                        name: string;
                        description?: string;
                        channel: string;
                        feeType: "flat" | "percentage" | "hybrid";
                        flatFee: string | null;
                        percentageFee: string | null;
                        minAmount: string | null;
                        maxAmount: string | null;
                        active: boolean;
                      }) => (
                      <TableRow key={fee.id}>
                        <TableCell>
                          <div className="font-medium">{fee.name}</div>
                          <div className="text-sm text-gray-500">{fee.description}</div>
                        </TableCell>
                        <TableCell>{getChannelName(fee.channel)}</TableCell>
                        <TableCell className="capitalize">{fee.feeType}</TableCell>
                        <TableCell>
                          {fee.feeType === "flat" && (
                            <div className="flex items-center">
                              <DollarSign className="h-4 w-4 mr-1 text-green-600" />
                              {Number(fee.flatFee).toFixed(2)} BDT
                            </div>
                          )}
                          {fee.feeType === "percentage" && (
                            <div className="flex items-center">
                              <Percent className="h-4 w-4 mr-1 text-blue-600" />
                              {Number(fee.percentageFee).toFixed(2)}%
                            </div>
                          )}
                          {fee.feeType === "hybrid" && (
                            <div className="space-y-1">
                              <div className="flex items-center">
                                <DollarSign className="h-3 w-3 mr-1 text-green-600" />
                                {Number(fee.flatFee).toFixed(2)} BDT
                              </div>
                              <div className="flex items-center">
                                <Percent className="h-3 w-3 mr-1 text-blue-600" />
                                {Number(fee.percentageFee).toFixed(2)}%
                              </div>
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          {fee.minAmount && (
                            <div>From {Number(fee.minAmount).toFixed(2)} BDT</div>
                          )}
                          {fee.maxAmount ? (
                            <div>To {Number(fee.maxAmount).toFixed(2)} BDT</div>
                          ) : (
                            <div>No upper limit</div>
                          )}
                        </TableCell>
                        <TableCell>
                          {fee.active ? (
                            <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">
                              Active
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-300">
                              Inactive
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditFee(fee)}
                            >
                              <FilePenLine className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteFee(fee.id)}
                              className="text-red-500 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transactions" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Pending Remittance Transactions</CardTitle>
              <CardDescription>
                Review and process remittance requests
              </CardDescription>
            </CardHeader>
            <CardContent className="px-0 sm:px-6">
              {/* Mobile view - Card-based layout */}
              <div className="block md:hidden space-y-4">
                {pendingTransactions.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No pending transactions found
                  </div>
                ) : (
                  pendingTransactions.map((tx: ExtendedRemittanceTransaction) => (
                    <Card key={tx.id} className="rounded-md overflow-hidden border border-gray-200">
                      <CardHeader className="p-4 bg-slate-50 flex flex-row justify-between items-center">
                        <div>
                          <div className="font-medium flex items-center gap-1">
                            {getChannelName(tx.recipientChannel)}
                            <CopyButton value={tx.recipientChannel} size="sm" tooltipText="Copy channel" />
                            <Badge variant="outline" className="ml-2">
                              {formatDate(tx.createdAt)}
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-500 flex items-center gap-1">
                            Agent: {tx.agentUsername}
                            <CopyButton value={tx.agentUsername || ""} size="sm" tooltipText="Copy username" />
                          </div>
                        </div>
                        <Button
                          onClick={() => handleProcessTransaction(tx)}
                          size="sm"
                          className="whitespace-nowrap"
                        >
                          Process
                        </Button>
                      </CardHeader>
                      <CardContent className="p-4 grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Recipient</p>
                          {/* Bank Transfer Format */}
                          {tx.recipientChannel === "npsb_bank" ? (
                            <>
                              <div className="flex items-center gap-1">
                                <p className="text-sm font-medium">{tx.recipientName || "Bank User"}</p>
                                <CopyButton value={tx.recipientName || "Bank User"} size="sm" tooltipText="Copy name" />
                              </div>
                              <div className="flex items-center gap-1">
                                <p className="text-sm"><span className="font-medium">Account:</span> {tx.recipientAccount}</p>
                                <CopyButton value={tx.recipientAccount} size="sm" tooltipText="Copy account" />
                              </div>
                              {tx.recipientAdditionalInfo && (
                                <>
                                  {typeof tx.recipientAdditionalInfo === "string" ? (
                                    <div className="flex items-center gap-1">
                                      <p className="text-xs text-gray-700 truncate">
                                        <span className="font-medium">Bank:</span> {tx.recipientAdditionalInfo}
                                      </p>
                                      <CopyButton
                                        value={tx.recipientAdditionalInfo}
                                        size="sm"
                                        tooltipText="Copy bank info"
                                      />
                                    </div>
                                  ) : (
                                    <>
                                      {tx.recipientAdditionalInfo.bankName && (
                                        <div className="flex items-center gap-1">
                                          <p className="text-xs text-gray-700">
                                            <span className="font-medium">Bank:</span> {tx.recipientAdditionalInfo.bankName}
                                          </p>
                                          <CopyButton
                                            value={tx.recipientAdditionalInfo.bankName}
                                            size="sm"
                                            tooltipText="Copy bank name"
                                          />
                                        </div>
                                      )}
                                      {tx.recipientAdditionalInfo.branchName && (
                                        <div className="flex items-center gap-1">
                                          <p className="text-xs text-gray-700">
                                            <span className="font-medium">Branch:</span> {tx.recipientAdditionalInfo.branchName}
                                          </p>
                                          <CopyButton
                                            value={tx.recipientAdditionalInfo.branchName}
                                            size="sm"
                                            tooltipText="Copy branch name"
                                          />
                                        </div>
                                      )}
                                      {tx.recipientAdditionalInfo.routingNumber && (
                                        <div className="flex items-center gap-1">
                                          <p className="text-xs text-gray-700">
                                            <span className="font-medium">Routing #:</span> {tx.recipientAdditionalInfo.routingNumber}
                                          </p>
                                          <CopyButton
                                            value={tx.recipientAdditionalInfo.routingNumber}
                                            size="sm"
                                            tooltipText="Copy routing number"
                                          />
                                        </div>
                                      )}
                                    </>
                                  )}
                                </>
                              )}
                            </>
                          ) : (
                            <>
                              {/* Mobile Banking Format */}
                              <div className="flex items-center gap-1">
                                <p className="text-sm font-medium">{getChannelName(tx.recipientChannel)}</p>
                                <CopyButton value={getChannelName(tx.recipientChannel)} size="sm" tooltipText="Copy payment type" />
                              </div>
                              <div className="flex items-center gap-1">
                                <p className="text-sm"><span className="font-medium">Number:</span> {tx.recipientAccount}</p>
                                <CopyButton value={tx.recipientAccount} size="sm" tooltipText="Copy number" />
                              </div>
                            </>
                          )}
                        </div>
                        
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Agent Details</p>
                          {tx.agentFullName && (
                            <div className="flex items-center gap-1">
                              <p className="text-sm">{tx.agentFullName}</p>
                              <CopyButton value={tx.agentFullName} size="sm" tooltipText="Copy name" />
                            </div>
                          )}
                          <div className="flex items-center gap-1">
                            <p className="text-xs text-gray-500">ID: {tx.agentId}</p>
                            <CopyButton value={tx.agentId.toString()} size="sm" tooltipText="Copy ID" />
                          </div>
                          {tx.agentPhone && (
                            <div className="flex items-center gap-1">
                              <p className="text-xs text-gray-500">{tx.agentPhone}</p>
                              <CopyButton value={tx.agentPhone} size="sm" tooltipText="Copy phone" />
                            </div>
                          )}
                          {tx.agentEmail && (
                            <div className="flex items-center gap-1">
                              <p className="text-xs text-gray-500 truncate max-w-[120px]">{tx.agentEmail}</p>
                              <CopyButton value={tx.agentEmail} size="sm" tooltipText="Copy email" />
                            </div>
                          )}
                        </div>
                        
                        <div className="space-y-1 col-span-2 border-t pt-2 mt-2">
                          <div className="grid grid-cols-3 gap-2">
                            <div>
                              <p className="text-xs text-gray-500">Amount</p>
                              <div className="flex items-center gap-1">
                                <p className="text-sm font-medium">{Number(tx.amount).toFixed(2)} ৳</p>
                                <CopyButton value={Number(tx.amount).toFixed(2)} size="sm" tooltipText="Copy amount" />
                              </div>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">Fee</p>
                              <div className="flex items-center gap-1">
                                <p className="text-sm">
                                  {tx.feeAmount ? Number(tx.feeAmount).toFixed(2) : '0.00'} ৳
                                  {tx.feeDetails && (
                                    <span className="text-xs text-gray-500 ml-1">
                                      ({tx.feeDetails.name})
                                    </span>
                                  )}
                                </p>
                                <CopyButton 
                                  value={tx.feeAmount ? Number(tx.feeAmount).toFixed(2) : '0.00'} 
                                  size="sm" 
                                  tooltipText="Copy fee" 
                                />
                              </div>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">Total</p>
                              <div className="flex items-center gap-1">
                                <p className="text-sm font-bold">{Number(tx.totalAmount).toFixed(2)} ৳</p>
                                <CopyButton value={Number(tx.totalAmount).toFixed(2)} size="sm" tooltipText="Copy total" />
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {tx.notes && (
                          <div className="col-span-2 border-t pt-2">
                            <p className="text-xs text-gray-500">Notes</p>
                            <div className="flex items-center gap-1">
                              <p className="text-sm">{tx.notes}</p>
                              <CopyButton value={tx.notes} size="sm" tooltipText="Copy notes" />
                            </div>
                          </div>
                        )}
                        
                        {tx.agentBalance && (
                          <div className="col-span-2 border-t pt-2">
                            <div className="flex items-center gap-1 text-sm font-medium text-emerald-600">
                              <span>Balance: ৳ {parseFloat(tx.agentBalance).toLocaleString()}</span>
                              <CopyButton value={tx.agentBalance} size="sm" tooltipText="Copy balance" />
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
              
              {/* Desktop view - Table layout */}
              <div className="hidden md:block">
                <ScrollArea className="h-[500px]">
                  <Table>
                    <TableCaption>List of pending remittance transactions</TableCaption>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Agent</TableHead>
                        <TableHead>Recipient</TableHead>
                        <TableHead>Channel</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Fee</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {pendingTransactions.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={8} className="text-center py-8 text-gray-500">
                            No pending transactions found
                          </TableCell>
                        </TableRow>
                      ) : (
                        pendingTransactions.map((tx: ExtendedRemittanceTransaction) => (
                          <TableRow key={tx.id}>
                            <TableCell className="whitespace-nowrap">
                              <div className="flex items-center gap-1">
                                {formatDate(tx.createdAt)}
                                <CopyButton value={formatDate(tx.createdAt)} size="sm" tooltipText="Copy date" />
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <div className="font-medium">{tx.agentUsername}</div>
                                <CopyButton value={tx.agentUsername || ""} size="sm" tooltipText="Copy username" />
                              </div>
                              {tx.agentFullName && (
                                <div className="flex items-center gap-1 text-sm text-gray-700">
                                  {tx.agentFullName}
                                  <CopyButton value={tx.agentFullName} size="sm" tooltipText="Copy full name" />
                                </div>
                              )}
                              <div className="flex items-center gap-1 text-xs text-gray-500">
                                ID: {tx.agentId}
                                <CopyButton value={tx.agentId.toString()} size="sm" tooltipText="Copy ID" />
                              </div>
                              {tx.agentEmail && (
                                <div className="flex items-center gap-1 text-xs text-gray-500">
                                  <span className="truncate max-w-[100px] sm:max-w-[150px]">{tx.agentEmail}</span>
                                  <CopyButton value={tx.agentEmail} size="sm" tooltipText="Copy email" />
                                </div>
                              )}
                              {tx.agentPhone && (
                                <div className="flex items-center gap-1 text-xs text-gray-500">
                                  {tx.agentPhone}
                                  <CopyButton value={tx.agentPhone} size="sm" tooltipText="Copy phone" />
                                </div>
                              )}
                              {tx.agentBalance && (
                                <div className="flex items-center gap-1 text-xs font-medium text-emerald-600">
                                  Balance: ৳ {parseFloat(tx.agentBalance).toLocaleString()}
                                  <CopyButton value={tx.agentBalance} size="sm" tooltipText="Copy balance" />
                                </div>
                              )}
                            </TableCell>
                            <TableCell>
                              {/* Bank Transfer Format */}
                              {tx.recipientChannel === "npsb_bank" ? (
                                <>
                                  {tx.recipientName ? (
                                    <div className="flex items-center gap-1">
                                      <div className="font-medium">{tx.recipientName}</div>
                                      <CopyButton value={tx.recipientName} size="sm" tooltipText="Copy name" />
                                    </div>
                                  ) : (
                                    <div className="flex items-center gap-1">
                                      <div className="font-medium">Bank User</div>
                                      <CopyButton value="Bank User" size="sm" tooltipText="Copy name" />
                                    </div>
                                  )}
                                  <div className="flex items-center gap-1 text-sm text-gray-500">
                                    <span className="font-medium">Account:</span> {tx.recipientAccount}
                                    <CopyButton value={tx.recipientAccount} size="sm" tooltipText="Copy account number" />
                                  </div>
                                  {tx.recipientAdditionalInfo && (
                                    <>
                                      {typeof tx.recipientAdditionalInfo === "string" ? (
                                        <div className="flex items-center gap-1 text-xs text-gray-500">
                                          <span className="font-medium">Bank:</span>
                                          <span className="truncate max-w-[150px]">{tx.recipientAdditionalInfo}</span>
                                          <CopyButton 
                                            value={tx.recipientAdditionalInfo}
                                            size="sm" 
                                            tooltipText="Copy bank info" 
                                          />
                                        </div>
                                      ) : (
                                        <>
                                          {tx.recipientAdditionalInfo.bankName && (
                                            <div className="flex items-center gap-1 text-xs text-gray-500">
                                              <span className="font-medium">Bank:</span>
                                              <span>{tx.recipientAdditionalInfo.bankName}</span>
                                              <CopyButton 
                                                value={tx.recipientAdditionalInfo.bankName}
                                                size="sm" 
                                                tooltipText="Copy bank name" 
                                              />
                                            </div>
                                          )}
                                          {tx.recipientAdditionalInfo.branchName && (
                                            <div className="flex items-center gap-1 text-xs text-gray-500">
                                              <span className="font-medium">Branch:</span>
                                              <span>{tx.recipientAdditionalInfo.branchName}</span>
                                              <CopyButton 
                                                value={tx.recipientAdditionalInfo.branchName}
                                                size="sm" 
                                                tooltipText="Copy branch name" 
                                              />
                                            </div>
                                          )}
                                          {tx.recipientAdditionalInfo.routingNumber && (
                                            <div className="flex items-center gap-1 text-xs text-gray-500">
                                              <span className="font-medium">Routing #:</span>
                                              <span>{tx.recipientAdditionalInfo.routingNumber}</span>
                                              <CopyButton 
                                                value={tx.recipientAdditionalInfo.routingNumber}
                                                size="sm" 
                                                tooltipText="Copy routing number" 
                                              />
                                            </div>
                                          )}
                                        </>
                                      )}
                                    </>
                                  )}
                                </>
                              ) : (
                                <>
                                  {/* Mobile Banking Format */}
                                  <div className="flex items-center gap-1">
                                    <div className="font-medium">{getChannelName(tx.recipientChannel)}</div>
                                    <CopyButton value={getChannelName(tx.recipientChannel)} size="sm" tooltipText="Copy payment type" />
                                  </div>
                                  <div className="flex items-center gap-1 text-sm text-gray-500">
                                    <span className="font-medium">Number:</span> {tx.recipientAccount}
                                    <CopyButton value={tx.recipientAccount} size="sm" tooltipText="Copy number" />
                                  </div>
                                </>
                              )}
                              {tx.notes && (
                                <div className="flex items-center gap-1 text-xs text-gray-500">
                                  <span className="truncate max-w-[150px]">Notes: {tx.notes}</span>
                                  <CopyButton value={tx.notes} size="sm" tooltipText="Copy notes" />
                                </div>
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                {getChannelName(tx.recipientChannel)}
                                <CopyButton value={tx.recipientChannel} size="sm" tooltipText="Copy channel code" />
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                {Number(tx.amount).toFixed(2)} BDT
                                <CopyButton value={Number(tx.amount).toFixed(2)} size="sm" tooltipText="Copy amount" />
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                {tx.feeAmount ? Number(tx.feeAmount).toFixed(2) : '0.00'} ৳
                                <CopyButton 
                                  value={tx.feeAmount ? Number(tx.feeAmount).toFixed(2) : '0.00'} 
                                  size="sm" 
                                  tooltipText="Copy fee amount" 
                                />
                              </div>
                              {tx.feeDetails && (
                                <div className="text-xs text-gray-500">
                                  {tx.feeDetails.name}
                                </div>
                              )}
                            </TableCell>
                            <TableCell className="font-medium">
                              <div className="flex items-center gap-1">
                                {Number(tx.totalAmount).toFixed(2)} BDT
                                <CopyButton value={Number(tx.totalAmount).toFixed(2)} size="sm" tooltipText="Copy total amount" />
                              </div>
                            </TableCell>
                            <TableCell>
                              <Button
                                onClick={() => handleProcessTransaction(tx)}
                                size="sm"
                              >
                                Process
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add/Edit Fee Dialog */}
      <Dialog open={isAddFeeDialogOpen} onOpenChange={setIsAddFeeDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{isEditMode ? "Edit Fee" : "Add New Remittance Fee"}</DialogTitle>
            <DialogDescription>
              {isEditMode
                ? "Update the fee details below."
                : "Configure a new remittance fee structure."}
            </DialogDescription>
          </DialogHeader>

          <Form {...feeForm}>
            <form onSubmit={feeForm.handleSubmit(onSubmitFee)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <FormField
                    control={feeForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Fee Name</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., bKash Small Transfers" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={feeForm.control}
                  name="channel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Channel</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select channel" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="npsb_bank">NPSB Bank</SelectItem>
                          <SelectItem value="bkash">bKash</SelectItem>
                          <SelectItem value="nagad">Nagad</SelectItem>
                          <SelectItem value="rocket">Rocket</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={feeForm.control}
                  name="feeType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Fee Type</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select fee type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="flat">Flat Fee</SelectItem>
                          <SelectItem value="percentage">Percentage</SelectItem>
                          <SelectItem value="hybrid">
                            Hybrid (Flat + Percentage)
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {(feeForm.watch("feeType") === "flat" ||
                  feeForm.watch("feeType") === "hybrid") && (
                  <FormField
                    control={feeForm.control}
                    name="flatFee"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Flat Fee (BDT)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            placeholder="e.g., 20.00"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                {(feeForm.watch("feeType") === "percentage" ||
                  feeForm.watch("feeType") === "hybrid") && (
                  <FormField
                    control={feeForm.control}
                    name="percentageFee"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Percentage Fee (%)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            placeholder="e.g., 0.5"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <FormField
                  control={feeForm.control}
                  name="minAmount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Minimum Amount (BDT)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="e.g., 100"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        Lowest amount this fee applies to
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={feeForm.control}
                  name="maxAmount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Maximum Amount (BDT)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="Leave empty for no upper limit"
                          value={field.value === null ? "" : field.value}
                          onChange={(e) => {
                            const value = e.target.value;
                            field.onChange(value === "" ? null : parseFloat(value));
                          }}
                        />
                      </FormControl>
                      <FormDescription>
                        Highest amount this fee applies to
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="col-span-2">
                  <FormField
                    control={feeForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Enter description for this fee structure"
                            className="resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="col-span-2">
                  <FormField
                    control={feeForm.control}
                    name="active"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">
                            Active
                          </FormLabel>
                          <FormDescription>
                            Make this fee active and available for use
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAddFeeDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={feeMutation.isPending}>
                  {feeMutation.isPending
                    ? "Saving..."
                    : isEditMode
                    ? "Update Fee"
                    : "Create Fee"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Process Transaction Dialog */}
      <Dialog open={isProcessingDialogOpen} onOpenChange={setIsProcessingDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Process Remittance Transaction</DialogTitle>
            <DialogDescription>
              Review and approve or reject this remittance request
            </DialogDescription>
          </DialogHeader>

          {processingTransaction && (
            <>
              <div className="grid grid-cols-2 gap-4 py-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium">Agent</p>
                  <div className="flex items-center gap-1">
                    <p className="text-sm">{processingTransaction.agentUsername}</p>
                    <CopyButton value={processingTransaction.agentUsername || ""} size="sm" tooltipText="Copy username" />
                  </div>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium">Date</p>
                  <p className="text-sm">{formatDate(processingTransaction.createdAt)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium">Recipient</p>
                  {processingTransaction.recipientChannel === "npsb_bank" ? (
                    <>
                      {processingTransaction.recipientName ? (
                        <div className="flex items-center gap-1">
                          <p className="text-sm">{processingTransaction.recipientName}</p>
                          <CopyButton value={processingTransaction.recipientName} size="sm" tooltipText="Copy name" />
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <p className="text-sm font-medium">Bank User</p>
                          <CopyButton value="Bank User" size="sm" tooltipText="Copy type" />
                        </div>
                      )}
                      <div className="flex items-center gap-1">
                        <p className="text-xs"><span className="font-medium">Account:</span> {processingTransaction.recipientAccount}</p>
                        <CopyButton value={processingTransaction.recipientAccount} size="sm" tooltipText="Copy account" />
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="flex items-center gap-1">
                        <p className="text-sm font-medium">{getChannelName(processingTransaction.recipientChannel)}</p>
                        <CopyButton value={getChannelName(processingTransaction.recipientChannel)} size="sm" tooltipText="Copy payment type" />
                      </div>
                      <div className="flex items-center gap-1">
                        <p className="text-xs"><span className="font-medium">Number:</span> {processingTransaction.recipientAccount}</p>
                        <CopyButton value={processingTransaction.recipientAccount} size="sm" tooltipText="Copy number" />
                      </div>
                    </>
                  )}
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium">Payment Method</p>
                  <div className="flex items-center gap-1">
                    <p className="text-sm">{getChannelName(processingTransaction.recipientChannel)}</p>
                    <CopyButton value={processingTransaction.recipientChannel} size="sm" tooltipText="Copy channel code" />
                  </div>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium">Amount</p>
                  <div className="flex items-center gap-1">
                    <p className="text-sm">{Number(processingTransaction.amount).toFixed(2)} BDT</p>
                    <CopyButton value={Number(processingTransaction.amount).toFixed(2)} size="sm" tooltipText="Copy amount" />
                  </div>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium">Fee</p>
                  <div className="flex items-center gap-1">
                    <p className="text-sm">{Number(processingTransaction.feeAmount).toFixed(2)} BDT</p>
                    <CopyButton value={Number(processingTransaction.feeAmount).toFixed(2)} size="sm" tooltipText="Copy fee" />
                  </div>
                </div>
                <div className="space-y-1 col-span-2">
                  <p className="text-sm font-medium">Total Amount</p>
                  <div className="flex items-center gap-1">
                    <p className="text-xl font-semibold">{Number(processingTransaction.totalAmount).toFixed(2)} BDT</p>
                    <CopyButton value={Number(processingTransaction.totalAmount).toFixed(2)} size="sm" tooltipText="Copy total" />
                  </div>
                </div>
                {processingTransaction.notes && (
                  <div className="space-y-1 col-span-2">
                    <p className="text-sm font-medium">Notes</p>
                    <div className="flex items-center gap-1">
                      <p className="text-sm">{processingTransaction.notes}</p>
                      <CopyButton value={processingTransaction.notes} size="sm" tooltipText="Copy notes" />
                    </div>
                  </div>
                )}
              </div>

              <Form {...processForm}>
                <form onSubmit={processForm.handleSubmit(onSubmitProcessTransaction)} className="space-y-4">
                  <FormField
                    control={processForm.control}
                    name="approve"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between space-x-3 space-y-0">
                        <FormLabel>Approve this transaction?</FormLabel>
                        <FormControl>
                          <div className="flex space-x-4">
                            <Button
                              type="button"
                              variant={field.value ? "default" : "outline"}
                              size="sm"
                              onClick={() => field.onChange(true)}
                              className={field.value ? "bg-green-600 hover:bg-green-700" : ""}
                            >
                              <CheckCircle className="h-4 w-4 mr-2" />
                              Approve
                            </Button>
                            <Button
                              type="button"
                              variant={!field.value ? "default" : "outline"}
                              size="sm"
                              onClick={() => field.onChange(false)}
                              className={!field.value ? "bg-red-600 hover:bg-red-700" : ""}
                            >
                              <XCircle className="h-4 w-4 mr-2" />
                              Reject
                            </Button>
                          </div>
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  {processForm.watch("approve") && (
                    <FormField
                      control={processForm.control}
                      name="transactionNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Transaction Number</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Enter transaction number or leave empty to generate automatically"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            Optional: Provide a specific transaction number or leave empty to generate one automatically
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  <FormField
                    control={processForm.control}
                    name="reason"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>
                          {processForm.watch("approve") ? "Comment (Optional)" : "Rejection Reason"}
                        </FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder={
                              processForm.watch("approve")
                                ? "Optional comment for the agent"
                                : "Provide a reason for rejecting this transaction"
                            }
                            className="resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsProcessingDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={processTransactionMutation.isPending}
                      className={
                        processForm.watch("approve")
                          ? "bg-green-600 hover:bg-green-700"
                          : "bg-red-600 hover:bg-red-700"
                      }
                    >
                      {processTransactionMutation.isPending
                        ? "Processing..."
                        : processForm.watch("approve")
                        ? "Confirm Approval"
                        : "Confirm Rejection"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </>
          )}
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}

export default AdminRemittancePage;