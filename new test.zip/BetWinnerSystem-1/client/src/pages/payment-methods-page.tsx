import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/layouts/app-layout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, Edit, Trash2, DollarSign } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

// Form schema
const formSchema = z.object({
  type: z.enum(["bkash", "nagad", "rocket", "bank", "bank_transfer", "crypto", "pix"]),
  name: z.string().min(1, "Name is required"),
  details: z.string().optional(),
  active: z.boolean().default(true)
});

type FormValues = z.infer<typeof formSchema>;

export default function PaymentMethodsPage() {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<any | null>(null);

  // Initialize form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      type: "bkash",
      name: "",
      details: "",
      active: true
    }
  });

  // Add funds form
  const [isAddFundsDialogOpen, setIsAddFundsDialogOpen] = useState(false);
  const [selectedPaymentMethodForFunds, setSelectedPaymentMethodForFunds] = useState<any>(null);
  
  const addFundsForm = useForm({
    resolver: zodResolver(z.object({
      amount: z.coerce.number().positive("Amount must be greater than 0"),
      currency: z.string().default("USDT"),
      paymentMethod: z.string(),
      walletAddress: z.string().optional(),
      transactionId: z.string().optional(),
      notes: z.string().optional()
    })),
    defaultValues: {
      amount: 0,
      currency: "USDT",
      paymentMethod: "",
      walletAddress: "",
      transactionId: "",
      notes: ""
    }
  });

  // Fetch payment methods
  const { data: paymentMethods, isLoading, error, refetch } = useQuery({
    queryKey: ['/api/payment-methods'],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/payment-methods");
      return await response.json();
    }
  });

  // Add Funds mutation
  const addFundsMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/topup", data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Funds Request Submitted",
        description: "Your request to add funds has been submitted successfully."
      });
      setIsAddFundsDialogOpen(false);
      addFundsForm.reset({
        amount: 0,
        currency: "USDT",
        paymentMethod: "",
        walletAddress: "",
        transactionId: "",
        notes: ""
      });
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/transactions/topup'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to submit funds request: ${(error as Error).message}`,
        variant: "destructive"
      });
    }
  });

  // Create/Update payment method
  const mutation = useMutation({
    mutationFn: async (data: FormValues) => {
      if (isEditMode && selectedMethod) {
        await apiRequest("PATCH", `/api/payment-methods/${selectedMethod.id}`, data);
      } else {
        await apiRequest("POST", "/api/payment-methods", data);
      }
    },
    onSuccess: () => {
      toast({
        title: `Payment Method ${isEditMode ? "Updated" : "Added"}`,
        description: `The payment method has been ${isEditMode ? "updated" : "added"} successfully.`
      });
      setIsAddDialogOpen(false);
      form.reset();
      setIsEditMode(false);
      setSelectedMethod(null);
      queryClient.invalidateQueries({ queryKey: ['/api/payment-methods'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${isEditMode ? "update" : "add"} payment method: ${(error as Error).message}`,
        variant: "destructive"
      });
    }
  });

  // Delete payment method
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/payment-methods/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Payment Method Deleted",
        description: "The payment method has been deleted successfully."
      });
      queryClient.invalidateQueries({ queryKey: ['/api/payment-methods'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete payment method: ${(error as Error).message}`,
        variant: "destructive"
      });
    }
  });

  const onSubmit = (values: FormValues) => {
    mutation.mutate(values);
  };

  const handleAddMethod = () => {
    form.reset({
      type: "bkash",
      name: "",
      details: "",
      active: true
    });
    setIsEditMode(false);
    setSelectedMethod(null);
    setIsAddDialogOpen(true);
  };

  const handleEditMethod = (method: any) => {
    form.reset({
      type: method.type,
      name: method.name,
      details: method.details || "",
      active: method.active
    });
    setIsEditMode(true);
    setSelectedMethod(method);
    setIsAddDialogOpen(true);
  };

  const handleDeleteMethod = (id: number) => {
    if (confirm("Are you sure you want to delete this payment method?")) {
      deleteMutation.mutate(id);
    }
  };
  
  const handleAddFunds = (method: any) => {
    setSelectedPaymentMethodForFunds(method);
    addFundsForm.reset({
      amount: 0,
      currency: "USDT",
      paymentMethod: method.id.toString(),
      walletAddress: "",
      transactionId: "",
      notes: ""
    });
    setIsAddFundsDialogOpen(true);
  };
  
  const onAddFundsSubmit = (data: any) => {
    addFundsMutation.mutate({
      amount: data.amount,
      currency: data.currency,
      paymentMethod: data.paymentMethod,
      walletAddress: data.walletAddress,
      transactionId: data.transactionId,
      notes: data.notes
    });
  };

  const getMethodTypeBadge = (type: string) => {
    switch (type) {
      case "bkash":
        return <Badge className="bg-pink-100 text-pink-800 hover:bg-pink-200">bKash</Badge>;
      case "bank":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">Bank</Badge>;
      case "bank_transfer":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">Bank Transfer</Badge>;
      case "nagad":
        return <Badge className="bg-orange-100 text-orange-800 hover:bg-orange-200">Nagad</Badge>;
      case "rocket":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-200">Rocket</Badge>;
      case "crypto":
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-200">Crypto</Badge>;
      case "pix":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-200">PIX</Badge>;
      default:
        return <Badge>{type}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex justify-center items-center h-[50vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Loading payment methods...</span>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Payment Methods</h2>
            <p className="text-muted-foreground">
              Manage payment methods for deposits and withdrawals
            </p>
          </div>
          <Button onClick={handleAddMethod}>Add Payment Method</Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Available Payment Methods</CardTitle>
            <CardDescription>
              Methods that players can use for deposits and withdrawals
            </CardDescription>
          </CardHeader>
          <CardContent>
            {error ? (
              <div className="text-center py-6 text-destructive">
                Failed to load payment methods. Please try again.
              </div>
            ) : !paymentMethods || paymentMethods.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">
                <p>No payment methods found.</p>
                <Button 
                  variant="outline" 
                  onClick={handleAddMethod} 
                  className="mt-4"
                >
                  Add Your First Payment Method
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">ID</th>
                      <th className="text-left py-3 px-4">Name</th>
                      <th className="text-left py-3 px-4">Type</th>
                      <th className="text-left py-3 px-4">Details</th>
                      <th className="text-left py-3 px-4">Status</th>
                      <th className="text-left py-3 px-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paymentMethods.map((method: any) => (
                      <tr key={method.id} className="border-b hover:bg-muted/50">
                        <td className="py-3 px-4">{method.id}</td>
                        <td className="py-3 px-4">{method.name}</td>
                        <td className="py-3 px-4">{getMethodTypeBadge(method.type)}</td>
                        <td className="py-3 px-4">
                          <div className="max-w-md truncate">
                            {method.details ? 
                              (typeof method.details === 'string' ? 
                                method.details : 
                                JSON.stringify(method.details)) 
                              : "-"}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <Badge 
                            variant={method.active ? "default" : "secondary"}
                            className={method.active ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}
                          >
                            {method.active ? "Active" : "Inactive"}
                          </Badge>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex space-x-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleEditMethod(method)}
                            >
                              <Edit className="h-4 w-4 mr-1" />
                              Edit
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="text-red-600 hover:text-red-700"
                              onClick={() => handleDeleteMethod(method.id)}
                              disabled={deleteMutation.isPending}
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Delete
                            </Button>
                            <Button 
                              variant="default" 
                              size="sm"
                              onClick={() => handleAddFunds(method)}
                            >
                              <DollarSign className="h-4 w-4 mr-1" />
                              Add Funds
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Add/Edit Payment Method Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{isEditMode ? "Edit Payment Method" : "Add Payment Method"}</DialogTitle>
            <DialogDescription>
              {isEditMode 
                ? "Update the details of the selected payment method." 
                : "Add a new payment method to the system."}
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Payment Type</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select payment type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="bkash">bKash</SelectItem>
                        <SelectItem value="nagad">Nagad</SelectItem>
                        <SelectItem value="rocket">Rocket</SelectItem>
                        <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                        <SelectItem value="crypto">Cryptocurrency</SelectItem>
                        <SelectItem value="pix">PIX</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      The type of payment method
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., 'bKash Personal'" {...field} />
                    </FormControl>
                    <FormDescription>
                      A descriptive name for this payment method
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="details"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Details</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="e.g., 'Account number: 01712345678'" 
                        {...field} 
                      />
                    </FormControl>
                    <FormDescription>
                      Account details or instructions for this payment method
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="active"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">
                        Active Status
                      </FormLabel>
                      <FormDescription>
                        Enable this payment method for users
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={mutation.isPending}
                >
                  {mutation.isPending ? "Saving..." : (isEditMode ? "Update" : "Add")}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Add Funds Dialog */}
      <Dialog open={isAddFundsDialogOpen} onOpenChange={setIsAddFundsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add Funds</DialogTitle>
            <DialogDescription>
              Add funds to your account using the selected payment method.
            </DialogDescription>
          </DialogHeader>
          
          {selectedPaymentMethodForFunds && (
            <div className="mb-4">
              <div className="flex items-center space-x-2 mb-2">
                <span className="font-medium">Selected Payment Method:</span>
                <Badge className="ml-1">{selectedPaymentMethodForFunds.name}</Badge>
                {getMethodTypeBadge(selectedPaymentMethodForFunds.type)}
              </div>
              <div className="bg-muted p-3 rounded-md text-sm">
                <p className="font-medium">Instructions:</p>
                <p className="mt-1">
                  {selectedPaymentMethodForFunds.details ? 
                    (typeof selectedPaymentMethodForFunds.details === 'string' ? 
                      selectedPaymentMethodForFunds.details : 
                      JSON.stringify(selectedPaymentMethodForFunds.details)) 
                    : "No specific instructions."}
                </p>
              </div>
            </div>
          )}
          
          <Form {...addFundsForm}>
            <form onSubmit={addFundsForm.handleSubmit(onAddFundsSubmit)} className="space-y-4">
              <FormField
                control={addFundsForm.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Amount</FormLabel>
                    <FormControl>
                      <Input {...field} type="number" step="0.01" min="0" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={addFundsForm.control}
                name="currency"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Currency</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select currency" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="USDT">USDT</SelectItem>
                        <SelectItem value="BDT">BDT</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {selectedPaymentMethodForFunds?.type === "crypto" && (
                <>
                  <div className="bg-blue-50 border border-blue-200 rounded-md p-4 mb-4">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <svg className="h-5 w-5 text-blue-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <div className="ml-3">
                        <h3 className="text-sm font-medium text-blue-800">Crypto Payment Information</h3>
                        {selectedPaymentMethodForFunds?.name === "Binance Pay" && (
                          <div className="mt-2 text-sm text-blue-700">
                            <p>Binance Pay ID: <span className="font-mono font-medium">168137682</span></p>
                            <p className="mt-1">Use this ID in the Binance Pay app to complete your payment.</p>
                          </div>
                        )}
                        {selectedPaymentMethodForFunds?.name === "USDT (TRC20)" && (
                          <div className="mt-2 text-sm text-blue-700">
                            <p>Wallet Address: <span className="font-mono font-medium break-all">TGbTPbHySdZai4Yyy2KkMiM2daCEW65AVu</span></p>
                            <p className="mt-1">Send USDT to this wallet address using TRC20 network only.</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <FormField
                    control={addFundsForm.control}
                    name="walletAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Your Wallet Address/ID</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Enter your wallet address or ID" />
                        </FormControl>
                        <FormDescription>
                          The wallet address you're sending funds from (for reference)
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </>
              )}
              
              {selectedPaymentMethodForFunds?.type === "pix" && (
                <>
                  <div className="bg-green-50 border border-green-200 rounded-md p-4 mb-4">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <svg className="h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <div className="ml-3">
                        <h3 className="text-sm font-medium text-green-800">PIX Payment Information</h3>
                        <div className="mt-2 text-sm text-green-700">
                          <p>PIX Key: <span className="font-mono font-medium">example@email.com</span></p>
                          <p className="mt-1">Use this PIX key to transfer funds. Include your agent ID in the description.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <FormField
                    control={addFundsForm.control}
                    name="transactionId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>PIX Transaction ID</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Enter your PIX transaction ID" />
                        </FormControl>
                        <FormDescription>
                          The transaction ID from your PIX payment
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </>
              )}
              
              <FormField
                control={addFundsForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        placeholder="Additional information about your transaction"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsAddFundsDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={addFundsMutation.isPending}
                >
                  {addFundsMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    "Add Funds"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}