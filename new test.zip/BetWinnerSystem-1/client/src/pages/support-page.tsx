import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { getQueryFn, apiRequest, queryClient } from "@/lib/queryClient";
import { AppLayout } from "@/layouts/app-layout";
import { Send, RefreshCw, User } from "lucide-react";

interface Message {
  id: string;
  content: string;
  sender: "admin" | "user";
  timestamp: string;
  read: boolean;
}

interface SupportTicket {
  id: string;
  subject: string;
  status: "open" | "closed";
  lastActivity: string;
  unreadCount: number;
  messages: Message[];
}

interface NewTicket {
  subject: string;
  message: string;
}

interface NewMessage {
  ticketId: string;
  message: string;
}

export default function SupportPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [showNewTicketForm, setShowNewTicketForm] = useState(false);
  const [newTicketSubject, setNewTicketSubject] = useState("");
  const [newTicketMessage, setNewTicketMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch tickets
  const { data: tickets = [], refetch: refetchTickets } = useQuery<SupportTicket[]>({
    queryKey: ["/api/support/tickets"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Create new ticket mutation
  const createTicketMutation = useMutation({
    mutationFn: async (data: NewTicket) => {
      const res = await apiRequest("POST", "/api/support/tickets", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Ticket created",
        description: "Your support ticket has been created successfully.",
      });
      setNewTicketSubject("");
      setNewTicketMessage("");
      setShowNewTicketForm(false);
      refetchTickets();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create ticket",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (data: NewMessage) => {
      const res = await apiRequest("POST", "/api/support/messages", data);
      return await res.json();
    },
    onSuccess: () => {
      setNewMessage("");
      refetchTickets();
      // If we have a selected ticket, update it from the refreshed data
      if (selectedTicket) {
        queryClient.invalidateQueries({ queryKey: ["/api/support/tickets"] });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send message",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mark ticket as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (ticketId: string) => {
      const res = await apiRequest("POST", `/api/support/tickets/${ticketId}/read`, {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/support/tickets"] });
    },
  });

  // Scroll to bottom of messages when selected ticket changes or new messages arrive
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [selectedTicket]);

  // When selecting a ticket, mark unread messages as read
  const handleSelectTicket = (ticket: SupportTicket) => {
    setSelectedTicket(ticket);
    if (ticket.unreadCount > 0) {
      markAsReadMutation.mutate(ticket.id);
    }
  };

  const handleCreateTicket = () => {
    if (!newTicketSubject.trim() || !newTicketMessage.trim()) {
      toast({
        title: "Invalid input",
        description: "Please provide both subject and message for your ticket.",
        variant: "destructive",
      });
      return;
    }

    createTicketMutation.mutate({
      subject: newTicketSubject,
      message: newTicketMessage,
    });
  };

  const handleSendMessage = () => {
    if (!selectedTicket || !newMessage.trim()) return;

    sendMessageMutation.mutate({
      ticketId: selectedTicket.id,
      message: newMessage,
    });
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Support Chat</h1>
        <p className="text-gray-500">Get help from our admin team</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Tickets List */}
        <div className="md:col-span-1">
          <Card className="h-[600px] flex flex-col">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle>Your Tickets</CardTitle>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => refetchTickets()}
                >
                  <RefreshCw className="h-4 w-4" />
                </Button>
              </div>
              <CardDescription>Select a ticket to view the conversation</CardDescription>
            </CardHeader>
            <CardContent className="flex-1 overflow-hidden">
              <Button 
                className="w-full mb-4" 
                onClick={() => setShowNewTicketForm(true)}
              >
                Create New Ticket
              </Button>
              
              {showNewTicketForm && (
                <Card className="mb-4 border-2 border-primary-100">
                  <CardContent className="pt-4 space-y-3">
                    <Input
                      placeholder="Ticket Subject"
                      value={newTicketSubject}
                      onChange={(e) => setNewTicketSubject(e.target.value)}
                    />
                    <Textarea
                      placeholder="Describe your issue in detail..."
                      rows={3}
                      value={newTicketMessage}
                      onChange={(e) => setNewTicketMessage(e.target.value)}
                    />
                    <div className="flex space-x-2">
                      <Button 
                        size="sm" 
                        className="flex-1"
                        onClick={handleCreateTicket}
                        disabled={createTicketMutation.isPending}
                      >
                        {createTicketMutation.isPending ? "Creating..." : "Create Ticket"}
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex-1"
                        onClick={() => setShowNewTicketForm(false)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              <ScrollArea className="h-[calc(600px-140px)]">
                {tickets.length === 0 ? (
                  <div className="text-center py-6 text-gray-500">
                    <p>No support tickets yet</p>
                    <p className="text-sm">Create one to get help</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {tickets.map((ticket) => (
                      <div
                        key={ticket.id}
                        className={`p-3 rounded-md cursor-pointer hover:bg-gray-100 ${
                          selectedTicket?.id === ticket.id ? "bg-primary-50 border border-primary-200" : ""
                        }`}
                        onClick={() => handleSelectTicket(ticket)}
                      >
                        <div className="flex justify-between">
                          <div className="font-medium truncate max-w-[70%]">{ticket.subject}</div>
                          <Badge variant={ticket.status === "open" ? "default" : "secondary"}>
                            {ticket.status}
                          </Badge>
                        </div>
                        <div className="flex justify-between mt-1 text-xs text-gray-500">
                          <span>Last activity: {ticket.lastActivity}</span>
                          {ticket.unreadCount > 0 && (
                            <Badge variant="destructive" className="text-[10px] py-0 px-1.5">
                              {ticket.unreadCount} new
                            </Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        {/* Chat Area */}
        <div className="md:col-span-2">
          <Card className="h-[600px] flex flex-col">
            <CardHeader className="pb-3">
              <CardTitle>
                {selectedTicket 
                  ? selectedTicket.subject 
                  : "Select a ticket or create a new one"}
              </CardTitle>
              {selectedTicket && (
                <CardDescription>
                  Ticket #{selectedTicket.id} • {selectedTicket.status}
                </CardDescription>
              )}
            </CardHeader>
            
            {selectedTicket ? (
              <>
                <CardContent className="flex-1 overflow-hidden pt-0">
                  <ScrollArea className="h-[calc(600px-180px)]">
                    <div className="space-y-4 pb-4 px-1">
                      {selectedTicket.messages.map((message, index) => (
                        <div
                          key={message.id}
                          className={`flex ${
                            message.sender === "user" ? "justify-end" : "justify-start"
                          }`}
                        >
                          <div
                            className={`max-w-[80%] rounded-lg p-3 ${
                              message.sender === "user"
                                ? "bg-primary-100 text-primary-900"
                                : "bg-gray-100 text-gray-900"
                            }`}
                          >
                            <div className="flex items-center gap-2 mb-1">
                              {message.sender === "admin" ? (
                                <Badge variant="outline" className="bg-gray-50 text-gray-700">
                                  Admin
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="bg-primary-50 text-primary-700">
                                  You
                                </Badge>
                              )}
                              <span className="text-xs text-gray-500">
                                {formatTimestamp(message.timestamp)}
                              </span>
                            </div>
                            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                          </div>
                        </div>
                      ))}
                      <div ref={messagesEndRef} />
                    </div>
                  </ScrollArea>
                </CardContent>
                
                <div className="p-4 border-t">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Type your message here..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                    />
                    <Button 
                      onClick={handleSendMessage}
                      disabled={!newMessage.trim() || sendMessageMutation.isPending}
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center p-6">
                  <div className="bg-gray-100 rounded-full p-4 inline-block mb-3">
                    <User className="h-8 w-8 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-1">No Conversation Selected</h3>
                  <p className="text-gray-500 mb-4">
                    Select an existing ticket from the list or create a new one to start a conversation
                  </p>
                  <Button onClick={() => setShowNewTicketForm(true)}>
                    Create New Ticket
                  </Button>
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
