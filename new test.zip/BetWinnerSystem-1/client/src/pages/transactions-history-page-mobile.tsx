import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { AppLayout } from '@/layouts/app-layout';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from '@/components/ui/input';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon, Download, Search, Camera, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { Loader2 } from 'lucide-react';
import { apiRequest } from '@/lib/apiRequest';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import html2canvas from 'html2canvas';
import { useToast } from '@/hooks/use-toast';

export interface Transaction {
  id: string;
  originalId: number;
  type: string;
  transactionType: string;
  amount: number;
  currency: string;
  date: string;
  time: string;
  status: string;
  statusReason?: string;
  // Fields for specific transaction types
  convertedAmount?: number;
  paymentMethod?: string;
  walletAddress?: string;
  accountNumber?: string;
  bankDetails?: string;
  transactionId?: string;
  withdrawalMethod?: string;
  reference?: string;
  playerId?: string;
  paymentCode?: string;
  commissionAmount?: number;
  recipientChannel?: string;
  recipientName?: string;
  recipientAccount?: string;
  transactionNumber?: string;
  notes?: string;
  feeAmount?: number;
  totalAmount?: number;
}

export default function TransactionsHistoryPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [search, setSearch] = useState('');
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [typeFilter, setTypeFilter] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState<string[]>([]);
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [isStartDateOpen, setIsStartDateOpen] = useState(false);
  const [isEndDateOpen, setIsEndDateOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

  // Prepare query parameters based on filters
  const getQueryParams = () => {
    const params = new URLSearchParams();
    
    if (startDate) {
      params.append('startDate', startDate.toISOString());
    }
    
    if (endDate) {
      params.append('endDate', endDate.toISOString());
    }
    
    typeFilter.forEach(type => {
      params.append('type', type);
    });
    
    statusFilter.forEach(status => {
      params.append('status', status);
    });
    
    if (search) {
      params.append('search', search);
    }
    
    return params.toString();
  };

  // Fetch transactions with filters
  const { data: transactions, isLoading, refetch } = useQuery<Transaction[]>({
    queryKey: ['/api/transactions', getQueryParams()],
    queryFn: async () => {
      const queryString = getQueryParams();
      const url = `/api/transactions${queryString ? `?${queryString}` : ''}`;
      return apiRequest(url);
    }
  });

  // Apply client-side filtering when search updates
  useEffect(() => {
    if (!transactions) return;
    
    setFilteredTransactions(transactions);
  }, [transactions, search, typeFilter, statusFilter, startDate, endDate]);

  // Handle filter changes
  const handleTypeFilterChange = (value: string) => {
    if (value === "all") {
      setTypeFilter([]);
    } else {
      setTypeFilter(prev => {
        if (prev.includes(value)) {
          return prev.filter(t => t !== value);
        } else {
          return [...prev, value];
        }
      });
    }
  };

  const handleStatusFilterChange = (value: string) => {
    if (value === "all") {
      setStatusFilter([]);
    } else {
      setStatusFilter(prev => {
        if (prev.includes(value)) {
          return prev.filter(s => s !== value);
        } else {
          return [...prev, value];
        }
      });
    }
  };

  const handleSearch = () => {
    refetch();
  };

  const handleClearFilters = () => {
    setSearch('');
    setTypeFilter([]);
    setStatusFilter([]);
    setStartDate(undefined);
    setEndDate(undefined);
    refetch();
  };

  // Export transactions to CSV
  const exportToCSV = () => {
    if (!filteredTransactions.length) return;

    const headers = [
      'Transaction ID', 
      'Type', 
      'Amount', 
      'Currency', 
      'Date', 
      'Time', 
      'Status'
    ];

    const rows = filteredTransactions.map(tx => [
      tx.id,
      tx.type,
      tx.amount.toString(),
      tx.currency,
      tx.date,
      tx.time,
      tx.status
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `transactions_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  // Export transactions to PDF
  const exportToPDF = () => {
    if (!filteredTransactions.length) return;

    const doc = new jsPDF();
    
    // Add title
    doc.setFontSize(18);
    doc.text('Transaction History', 14, 22);
    
    // Add date
    doc.setFontSize(11);
    doc.text(`Generated on: ${format(new Date(), 'PPP')}`, 14, 30);
    
    // Add user info
    if (user) {
      doc.text(`User: ${user.username} (${user.agentId})`, 14, 38);
    }
    
    // Add table
    const headers = [
      'Transaction ID', 
      'Type', 
      'Amount', 
      'Date', 
      'Status'
    ];

    const rows = filteredTransactions.map(tx => [
      tx.id,
      tx.transactionType,
      `${tx.currency} ${tx.amount}`,
      `${tx.date}`,
      tx.status
    ]);

    // @ts-ignore - jspdf-autotable types
    doc.autoTable({
      head: [headers],
      body: rows,
      startY: 45,
      styles: { fontSize: 9 },
      headStyles: { fillColor: [66, 139, 202] },
      alternateRowStyles: { fillColor: [241, 245, 249] },
      margin: { top: 45 }
    });
    
    doc.save(`transactions_${format(new Date(), 'yyyy-MM-dd')}.pdf`);
  };

  // Helper to render status badge with appropriate color
  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">Pending</Badge>;
      case 'completed':
      case 'approved':
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Approved</Badge>;
      case 'failed':
      case 'rejected':
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Function to create and share transaction screenshot
  const captureAndShareTransaction = async (transaction: Transaction) => {
    setSelectedTransaction(transaction);
    
    // Wait for React to update the DOM with the selected transaction
    setTimeout(async () => {
      const transactionCard = document.getElementById(`transaction-${transaction.id}`);
      if (!transactionCard) {
        toast({
          title: "Error",
          description: "Could not create screenshot. Please try again.",
          variant: "destructive",
        });
        return;
      }
      
      try {
        const canvas = await html2canvas(transactionCard, {
          scale: 2,
          backgroundColor: "#ffffff",
          logging: false,
        });
        
        const imgData = canvas.toDataURL("image/png");
        
        // Try to use the Web Share API if available
        if (navigator.share) {
          const blob = await (await fetch(imgData)).blob();
          const file = new File([blob], `transaction-${transaction.id}.png`, { type: 'image/png' });
          
          await navigator.share({
            title: 'Transaction Details',
            text: `Transaction details for ${transaction.type} (${transaction.id})`,
            files: [file],
          });
          
          toast({
            title: "Success",
            description: "Transaction screenshot shared successfully!",
          });
        } else {
          // Fallback to download
          const link = document.createElement('a');
          link.href = imgData;
          link.download = `transaction-${transaction.id}.png`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          
          toast({
            title: "Success",
            description: "Transaction screenshot downloaded!",
          });
        }
      } catch (error) {
        console.error('Error sharing:', error);
        toast({
          title: "Error",
          description: "Could not share screenshot. Try saving it instead.",
          variant: "destructive",
        });
      } finally {
        setSelectedTransaction(null);
      }
    }, 100);
  };

  // Get transaction details based on type
  const getTransactionDetails = (transaction: Transaction) => {
    switch (transaction.transactionType) {
      case 'topup':
        return (
          <>
            <p className="text-sm text-gray-500">Payment Method: {transaction.paymentMethod}</p>
            {transaction.transactionId && <p className="text-sm text-gray-500">Transaction ID: {transaction.transactionId}</p>}
            {transaction.convertedAmount && <p className="text-sm text-gray-500">Converted: {transaction.convertedAmount} BDT</p>}
          </>
        );
      case 'withdrawal':
        return (
          <>
            <p className="text-sm text-gray-500">Method: {transaction.withdrawalMethod}</p>
            {transaction.reference && <p className="text-sm text-gray-500">Reference: {transaction.reference}</p>}
          </>
        );
      case 'player_deposit':
      case 'player_withdrawal':
        return (
          <>
            <p className="text-sm text-gray-500">Player ID: {transaction.playerId}</p>
            {transaction.paymentCode && <p className="text-sm text-gray-500">Payment Code: {transaction.paymentCode}</p>}
            {transaction.commissionAmount && <p className="text-sm text-gray-500">Commission: {transaction.commissionAmount} BDT</p>}
          </>
        );
      case 'remittance':
        return (
          <>
            <p className="text-sm text-gray-500">Channel: {transaction.recipientChannel}</p>
            <p className="text-sm text-gray-500">Recipient: {transaction.recipientName}</p>
            <p className="text-sm text-gray-500">Account: {transaction.recipientAccount}</p>
            {transaction.feeAmount && <p className="text-sm text-gray-500">Fee: {transaction.feeAmount} BDT</p>}
            {transaction.transactionNumber && <p className="text-sm text-gray-500">Transaction #: {transaction.transactionNumber}</p>}
          </>
        );
      default:
        return null;
    }
  };

  return (
    <AppLayout>
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold mb-6">Transaction History</h1>
        
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Filters</CardTitle>
            <CardDescription>Filter your transaction history</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Transaction Type</label>
                <Select onValueChange={handleTypeFilterChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="topup">USDT Top-up</SelectItem>
                    <SelectItem value="withdrawal">Withdrawal</SelectItem>
                    <SelectItem value="player_deposit">Player Deposit</SelectItem>
                    <SelectItem value="player_withdrawal">Player Withdrawal</SelectItem>
                    <SelectItem value="remittance">Remittance</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium mb-1 block">Status</label>
                <Select onValueChange={handleStatusFilterChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium mb-1 block">Search</label>
                <div className="flex">
                  <Input 
                    placeholder="Search transactions..." 
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="w-full"
                  />
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Start Date</label>
                <Popover open={isStartDateOpen} onOpenChange={setIsStartDateOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {startDate ? format(startDate, 'PPP') : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={startDate}
                      onSelect={(date) => {
                        setStartDate(date);
                        setIsStartDateOpen(false);
                      }}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div>
                <label className="text-sm font-medium mb-1 block">End Date</label>
                <Popover open={isEndDateOpen} onOpenChange={setIsEndDateOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {endDate ? format(endDate, 'PPP') : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={endDate}
                      onSelect={(date) => {
                        setEndDate(date);
                        setIsEndDateOpen(false);
                      }}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col sm:flex-row justify-between gap-4">
            <Button variant="outline" onClick={handleClearFilters} className="w-full sm:w-auto">
              Clear Filters
            </Button>
            <div className="flex gap-2 flex-wrap w-full sm:w-auto justify-end">
              <Button onClick={handleSearch} className="flex items-center gap-2">
                <Search className="h-4 w-4" />
                <span>Search</span>
              </Button>
              <Button onClick={exportToCSV} variant="outline" className="flex items-center gap-2">
                <Download className="h-4 w-4" />
                <span>CSV</span>
              </Button>
              <Button onClick={exportToPDF} variant="outline" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                <span>PDF</span>
              </Button>
            </div>
          </CardFooter>
        </Card>
        
        {/* Hidden div for screenshot generation */}
        {selectedTransaction && (
          <div id={`transaction-${selectedTransaction.id}`} className="fixed top-0 left-0 z-[-1000] bg-white p-6 w-[350px] border rounded-lg shadow-lg" style={{ opacity: 0 }}>
            <div className="border-b pb-2 mb-3">
              <h3 className="text-lg font-semibold">Transaction Receipt</h3>
              <p className="text-sm text-gray-500">BetWinner Agent Portal</p>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="font-medium">Transaction ID:</span>
                <span>{selectedTransaction.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Type:</span>
                <span>{selectedTransaction.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Amount:</span>
                <span>{selectedTransaction.amount} {selectedTransaction.currency}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Date:</span>
                <span>{selectedTransaction.date}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Time:</span>
                <span>{selectedTransaction.time}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Status:</span>
                <span>{selectedTransaction.status}</span>
              </div>
              
              {selectedTransaction.transactionType === 'topup' && (
                <>
                  <div className="flex justify-between">
                    <span className="font-medium">Payment Method:</span>
                    <span>{selectedTransaction.paymentMethod}</span>
                  </div>
                  {selectedTransaction.transactionId && (
                    <div className="flex justify-between">
                      <span className="font-medium">Transaction ID:</span>
                      <span>{selectedTransaction.transactionId}</span>
                    </div>
                  )}
                  {selectedTransaction.convertedAmount && (
                    <div className="flex justify-between">
                      <span className="font-medium">Converted:</span>
                      <span>{selectedTransaction.convertedAmount} BDT</span>
                    </div>
                  )}
                </>
              )}
              
              {selectedTransaction.transactionType === 'withdrawal' && (
                <>
                  <div className="flex justify-between">
                    <span className="font-medium">Method:</span>
                    <span>{selectedTransaction.withdrawalMethod}</span>
                  </div>
                  {selectedTransaction.reference && (
                    <div className="flex justify-between">
                      <span className="font-medium">Reference:</span>
                      <span>{selectedTransaction.reference}</span>
                    </div>
                  )}
                </>
              )}
              
              {['player_deposit', 'player_withdrawal'].includes(selectedTransaction.transactionType) && (
                <>
                  <div className="flex justify-between">
                    <span className="font-medium">Player ID:</span>
                    <span>{selectedTransaction.playerId}</span>
                  </div>
                  {selectedTransaction.paymentCode && (
                    <div className="flex justify-between">
                      <span className="font-medium">Payment Code:</span>
                      <span>{selectedTransaction.paymentCode}</span>
                    </div>
                  )}
                  {selectedTransaction.commissionAmount && (
                    <div className="flex justify-between">
                      <span className="font-medium">Commission:</span>
                      <span>{selectedTransaction.commissionAmount} BDT</span>
                    </div>
                  )}
                </>
              )}
              
              {selectedTransaction.transactionType === 'remittance' && (
                <>
                  <div className="flex justify-between">
                    <span className="font-medium">Channel:</span>
                    <span>{selectedTransaction.recipientChannel}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Recipient:</span>
                    <span>{selectedTransaction.recipientName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Account:</span>
                    <span>{selectedTransaction.recipientAccount}</span>
                  </div>
                  {selectedTransaction.feeAmount && (
                    <div className="flex justify-between">
                      <span className="font-medium">Fee:</span>
                      <span>{selectedTransaction.feeAmount} BDT</span>
                    </div>
                  )}
                  {selectedTransaction.transactionNumber && (
                    <div className="flex justify-between">
                      <span className="font-medium">Transaction #:</span>
                      <span>{selectedTransaction.transactionNumber}</span>
                    </div>
                  )}
                </>
              )}
            </div>
            <div className="border-t mt-4 pt-2 text-center text-xs text-gray-500">
              Generated on {format(new Date(), 'PPP')} at {format(new Date(), 'pp')}
            </div>
          </div>
        )}
        
        <Card>
          <CardHeader>
            <CardTitle>Transactions</CardTitle>
            <CardDescription>
              View your transaction history
              {typeFilter.length > 0 && (
                <span className="ml-2">
                  (Filtered by {typeFilter.join(', ')})
                </span>
              )}
              {statusFilter.length > 0 && (
                <span className="ml-2">
                  (Status: {statusFilter.join(', ')})
                </span>
              )}
            </CardDescription>
          </CardHeader>
          
          {isLoading ? (
            <div className="flex justify-center items-center py-10">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredTransactions && filteredTransactions.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <p>No transactions found.</p>
            </div>
          ) : (
            <div className="pb-4">
              {/* Desktop View */}
              <div className="hidden md:block overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Transaction</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Details</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>
                          <div className="font-medium">{transaction.date}</div>
                          <div className="text-sm text-gray-500">{transaction.time}</div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{transaction.type}</div>
                          <div className="text-sm text-gray-500">ID: {transaction.id}</div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{transaction.amount} {transaction.currency}</div>
                          {transaction.totalAmount && transaction.totalAmount !== transaction.amount && (
                            <div className="text-sm text-gray-500">
                              Total: {transaction.totalAmount} {transaction.currency}
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(transaction.status)}
                          {transaction.statusReason && (
                            <div className="text-xs text-gray-500 mt-1">{transaction.statusReason}</div>
                          )}
                        </TableCell>
                        <TableCell>
                          {getTransactionDetails(transaction)}
                        </TableCell>
                        <TableCell>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => captureAndShareTransaction(transaction)}
                            className="flex items-center gap-1"
                          >
                            <Camera className="h-4 w-4" />
                            <span>Share</span>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {/* Mobile View - Card-based layout */}
              <div className="md:hidden space-y-4 px-4">
                {filteredTransactions.map((transaction) => (
                  <Card key={transaction.id} className="overflow-hidden">
                    <CardHeader className="p-4 pb-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-base">{transaction.type}</CardTitle>
                          <CardDescription>ID: {transaction.id}</CardDescription>
                        </div>
                        <div>
                          {getStatusBadge(transaction.status)}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4 pt-2">
                      <div className="grid grid-cols-2 gap-2 mb-3">
                        <div>
                          <p className="text-sm font-medium text-gray-500">Date & Time</p>
                          <p>{transaction.date}, {transaction.time}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-500">Amount</p>
                          <p>{transaction.amount} {transaction.currency}</p>
                          {transaction.totalAmount && transaction.totalAmount !== transaction.amount && (
                            <p className="text-xs text-gray-500">
                              Total: {transaction.totalAmount} {transaction.currency}
                            </p>
                          )}
                        </div>
                      </div>
                      
                      <div className="space-y-1">
                        <p className="text-sm font-medium text-gray-500">Details</p>
                        {transaction.transactionType === 'topup' && (
                          <>
                            <p className="text-sm">Payment Method: {transaction.paymentMethod}</p>
                            {transaction.transactionId && <p className="text-sm">Transaction ID: {transaction.transactionId}</p>}
                            {transaction.convertedAmount && <p className="text-sm">Converted: {transaction.convertedAmount} BDT</p>}
                          </>
                        )}
                        
                        {transaction.transactionType === 'withdrawal' && (
                          <>
                            <p className="text-sm">Method: {transaction.withdrawalMethod}</p>
                            {transaction.reference && <p className="text-sm">Reference: {transaction.reference}</p>}
                          </>
                        )}
                        
                        {['player_deposit', 'player_withdrawal'].includes(transaction.transactionType) && (
                          <>
                            <p className="text-sm">Player ID: {transaction.playerId}</p>
                            {transaction.paymentCode && <p className="text-sm">Payment Code: {transaction.paymentCode}</p>}
                            {transaction.commissionAmount && <p className="text-sm">Commission: {transaction.commissionAmount} BDT</p>}
                          </>
                        )}
                        
                        {transaction.transactionType === 'remittance' && (
                          <>
                            <p className="text-sm">Channel: {transaction.recipientChannel}</p>
                            <p className="text-sm">Recipient: {transaction.recipientName}</p>
                            <p className="text-sm">Account: {transaction.recipientAccount}</p>
                            {transaction.feeAmount && <p className="text-sm">Fee: {transaction.feeAmount} BDT</p>}
                            {transaction.transactionNumber && <p className="text-sm">Transaction #: {transaction.transactionNumber}</p>}
                          </>
                        )}
                        
                        {transaction.statusReason && (
                          <p className="text-sm text-gray-500 mt-1">{transaction.statusReason}</p>
                        )}
                      </div>
                    </CardContent>
                    <CardFooter className="p-4 pt-0 flex justify-end">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => captureAndShareTransaction(transaction)}
                        className="w-full flex justify-center items-center gap-2"
                      >
                        <Camera className="h-4 w-4" />
                        <span>Share Screenshot</span>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </Card>
      </div>
    </AppLayout>
  );
}