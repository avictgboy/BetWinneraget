import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { AppLayout } from "@/layouts/app-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Send, Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface ChatMessage {
  id: number;
  senderId: number;
  senderName: string;
  recipientId?: number;
  message: string;
  read: boolean;
  timestamp: string;
  isAdmin?: boolean;
}

export default function ChatPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [message, setMessage] = useState("");
  const chatEndRef = useRef<HTMLDivElement>(null);
  const isAdmin = user?.role === "admin";

  // Fetch chat messages
  const { data: messages, isLoading, error } = useQuery({
    queryKey: ["/api/chat/messages"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/chat/messages");
      return await res.json() as ChatMessage[];
    },
    refetchInterval: 5000 // Poll every 5 seconds
  });

  // Mark messages as read
  const markAsReadMutation = useMutation({
    mutationFn: async (messageIds: number[]) => {
      await apiRequest("POST", "/api/chat/messages/read", { messageIds });
    }
  });

  // Send message
  const sendMessageMutation = useMutation({
    mutationFn: async (data: { message: string, recipientId?: number }) => {
      const response = await apiRequest("POST", "/api/chat/messages", data);
      return await response.json();
    },
    onSuccess: () => {
      setMessage("");
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to send message: ${(error as Error).message}`,
        variant: "destructive"
      });
    }
  });

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Mark unread messages as read
  useEffect(() => {
    if (messages && user) {
      const unreadMessages = messages.filter(
        msg => !msg.read && msg.recipientId === user.id
      );
      
      if (unreadMessages.length > 0) {
        markAsReadMutation.mutate(unreadMessages.map(msg => msg.id));
      }
    }
  }, [messages, user, markAsReadMutation]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    sendMessageMutation.mutate({ message });
  };

  // Format timestamp to readable format
  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    }).format(date);
  };

  // Get initials for avatar
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map(part => part[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex justify-center items-center h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Loading chat messages...</span>
        </div>
      </AppLayout>
    );
  }

  if (error) {
    return (
      <AppLayout>
        <Card>
          <CardHeader>
            <CardTitle className="text-destructive">Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Failed to load chat messages. Please try again later.</p>
          </CardContent>
        </Card>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto">
        <Card className="border-gray-200 dark:border-gray-700 shadow-md">
          <CardHeader className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
            <CardTitle>
              {isAdmin ? "Agent Support Chat" : "Support Chat"}
            </CardTitle>
            <CardDescription>
              {isAdmin 
                ? "Message your agents and respond to their inquiries" 
                : "Get assistance from admin support"}
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {/* Chat messages */}
            <div className="h-[60vh] overflow-y-auto p-4 bg-gray-50 dark:bg-gray-900">
              {messages && messages.length > 0 ? (
                <div className="space-y-4">
                  {messages.map((msg) => (
                    <div 
                      key={msg.id} 
                      className={`flex ${msg.senderId === user?.id ? 'justify-end' : 'justify-start'}`}
                    >
                      <div 
                        className={`flex max-w-[80%] ${
                          msg.senderId === user?.id 
                            ? 'flex-row-reverse' 
                            : 'flex-row'
                        }`}
                      >
                        <Avatar className={`h-8 w-8 ${msg.senderId === user?.id ? 'ml-2' : 'mr-2'}`}>
                          <AvatarFallback 
                            className={msg.senderId === user?.id 
                              ? "bg-blue-600 text-white" 
                              : "bg-gray-700 text-white"
                            }
                          >
                            {getInitials(msg.senderName)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div 
                            className={`rounded-lg px-4 py-2 ${
                              msg.senderId === user?.id 
                                ? 'bg-blue-600 text-white' 
                                : 'bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-gray-100'
                            }`}
                          >
                            <p>{msg.message}</p>
                          </div>
                          <div 
                            className={`text-xs mt-1 text-gray-500 ${
                              msg.senderId === user?.id ? 'text-right' : ''
                            }`}
                          >
                            <span className="font-medium">{msg.senderName}</span>
                            {" • "}
                            <span>{formatTimestamp(msg.timestamp)}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                  <div ref={chatEndRef} />
                </div>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <p className="text-gray-500 dark:text-gray-400">
                    No messages yet. Start a conversation!
                  </p>
                </div>
              )}
            </div>
            
            <Separator className="my-0" />
            
            {/* Message input */}
            <form onSubmit={handleSendMessage} className="p-4 bg-white dark:bg-gray-800">
              <div className="flex space-x-2">
                <Input
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-grow"
                  disabled={sendMessageMutation.isPending}
                />
                <Button 
                  type="submit" 
                  variant="default"
                  disabled={sendMessageMutation.isPending || !message.trim()}
                >
                  {sendMessageMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                  <span className="ml-2">Send</span>
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}