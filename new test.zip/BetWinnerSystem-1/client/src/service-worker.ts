/// <reference lib="webworker" />
/* eslint-disable no-restricted-globals */

// This service worker can be customized!
// See https://developers.google.com/web/tools/workbox/modules
// for the list of available Workbox modules, or add any other
// code you'd like.
// You can also remove this file if you'd prefer not to use a
// service worker, and the Workbox build step will be skipped.

declare const self: ServiceWorkerGlobalScope;

interface NotificationData {
  url?: string;
  title?: string;
  body?: string;
}

const CACHE_NAME = 'betwinner-agent-v1';
const OFFLINE_URL = '/offline.html';

// Resources to pre-cache
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/offline.html',
  '/manifest.json',
  '/favicon.ico',
  '/logo192.png',
  '/logo512.png'
];

// Install handler - pre-caches resources
self.addEventListener('install', (event: ExtendableEvent) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      await cache.addAll(PRECACHE_ASSETS);
      await self.skipWaiting();
    })()
  );
});

// Activate handler - clean up old caches
self.addEventListener('activate', (event: ExtendableEvent) => {
  event.waitUntil(
    (async () => {
      // Clean up old cache versions
      const cacheNames = await caches.keys();
      await Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
      
      await self.clients.claim();
    })()
  );
});

// Fetch handler - enable offline capabilities
self.addEventListener('fetch', (event: FetchEvent) => {
  // Skip cross-origin requests
  if (event.request.mode === 'navigate') {
    event.respondWith(
      (async () => {
        try {
          // First, try the network
          const networkResponse = await fetch(event.request);
          return networkResponse;
        } catch (error) {
          // Network failed, try to return the cached offline page
          const cache = await caches.open(CACHE_NAME);
          const cachedResponse = await cache.match(OFFLINE_URL);
          return cachedResponse || await fetch(event.request);
        }
      })()
    );
  } else if (event.request.destination === 'image' || 
             event.request.destination === 'font' || 
             event.request.destination === 'style' || 
             event.request.destination === 'script') {
    event.respondWith(
      (async () => {
        // Try the cache first, fall back to network
        const cache = await caches.open(CACHE_NAME);
        const cachedResponse = await cache.match(event.request);
        
        if (cachedResponse) {
          return cachedResponse;
        }
        
        try {
          // If not in cache, try the network
          const networkResponse = await fetch(event.request);
          
          // Cache the network response
          if (networkResponse.ok) {
            const clonedResponse = networkResponse.clone();
            event.waitUntil(cache.put(event.request, clonedResponse));
          }
          
          return networkResponse;
        } catch (error) {
          console.error('Fetch failed:', error);
          // Network failed completely, return fallback
          return new Response('Network error happened', {
            status: 408,
            headers: { 'Content-Type': 'text/plain' },
          });
        }
      })()
    );
  }
});

// Push notification handler
self.addEventListener('push', (event: PushEvent) => {
  const data = event.data?.json() as NotificationData ?? {};
  const options: NotificationOptions = {
    body: data.body || 'New notification',
    icon: '/logo192.png',
    badge: '/logo192.png',
    data: {
      url: data.url || '/',
    },
  };

  event.waitUntil(
    self.registration.showNotification(data.title || 'New Message', options)
  );
});

// Notification click handler
self.addEventListener('notificationclick', (event: NotificationEvent) => {
  event.notification.close();
  
  event.waitUntil(
    self.clients.matchAll({ type: 'window' })
      .then((windowClients: readonly WindowClient[]) => {
        // Check if there is already a window open
        for (const client of windowClients) {
          if (client.url === (event.notification.data as { url: string }).url && 'focus' in client) {
            return client.focus();
          }
        }
        // If no open window, open a new one
        if (self.clients.openWindow) {
          return self.clients.openWindow((event.notification.data as { url: string }).url);
        }
        return Promise.resolve();
      })
  );
});

export {};