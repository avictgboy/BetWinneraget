import { useEffect, useRef } from "react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Settings, User, LogOut } from "lucide-react";

interface UserMenuProps {
  onClose: () => void;
}

export function UserMenu({ onClose }: UserMenuProps) {
  const { user, logoutMutation } = useAuth();
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose();
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [onClose]);

  const handleLogout = () => {
    logoutMutation.mutate();
    onClose();
  };

  return (
    <div 
      ref={menuRef}
      className="absolute right-4 top-12 w-56 bg-gray-800 rounded-md shadow-xl py-1 z-50 border border-gray-700"
    >
      <div className="px-4 py-2 border-b border-gray-700">
        <p className="text-sm font-medium text-gray-200">{user?.fullName || user?.username}</p>
        <p className="text-xs text-gray-400 truncate">{user?.email}</p>
      </div>
      
      <ul>
        <li>
          <Link href="/profile">
            <div className="flex items-center px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 hover:text-white cursor-pointer" onClick={onClose}>
              <User className="w-4 h-4 mr-2" />
              Profile
            </div>
          </Link>
        </li>
        <li>
          <Link href="/settings">
            <div className="flex items-center px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 hover:text-white cursor-pointer" onClick={onClose}>
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </div>
          </Link>
        </li>
        <li className="border-t border-gray-700">
          <button
            className="flex items-center w-full px-4 py-2 text-sm text-gray-300 hover:bg-gray-700 hover:text-white"
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            <LogOut className="w-4 h-4 mr-2" />
            {logoutMutation.isPending ? "Logging out..." : "Logout"}
          </button>
        </li>
      </ul>
    </div>
  );
}
