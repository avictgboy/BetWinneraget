import { useState, useEffect } from "react";
import { Bell } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  getNotifications, 
  markNotificationAsRead, 
  type Notification 
} from "@/lib/firebase";

export function Notifications() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const fetchNotifications = async () => {
      const notifications = await getNotifications();
      setNotifications(notifications);
    };

    fetchNotifications();
    
    // In a real app, you would set up a real-time listener with Firebase
    const intervalId = setInterval(fetchNotifications, 30000);
    
    return () => clearInterval(intervalId);
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleMarkAsRead = async (notificationId: string) => {
    await markNotificationAsRead(notificationId);
    setNotifications(prevNotifications => 
      prevNotifications.map(notification => 
        notification.id === notificationId 
          ? { ...notification, read: true } 
          : notification
      )
    );
  };

  const renderEmptyState = () => (
    <div className="p-4 text-center">
      <p className="text-sm text-gray-500">No notifications yet</p>
    </div>
  );

  const formatNotificationTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    // Less than a minute
    if (diff < 60000) return 'Just now';
    
    // Less than an hour
    if (diff < 3600000) {
      const minutes = Math.floor(diff / 60000);
      return `${minutes}m ago`;
    }
    
    // Less than a day
    if (diff < 86400000) {
      const hours = Math.floor(diff / 3600000);
      return `${hours}h ago`;
    }
    
    // Format as date
    return date.toLocaleDateString();
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative text-gray-200 hover:text-white hover:bg-gray-700">
          <Bell className="h-6 w-6" />
          {unreadCount > 0 && (
            <span className="absolute top-0 right-0 bg-blue-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0 border-gray-700 bg-gray-800 text-gray-200" align="end">
        <div className="border-b border-gray-700 p-3">
          <h3 className="font-medium">Notifications</h3>
        </div>
        
        <ScrollArea className="h-[300px]">
          {notifications.length === 0 ? (
            <div className="p-4 text-center">
              <p className="text-sm text-gray-400">No notifications yet</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-700">
              {notifications.map((notification) => (
                <div 
                  key={notification.id}
                  className={`p-3 ${notification.read ? '' : 'bg-gray-700'}`}
                >
                  <div className="flex justify-between mb-1">
                    <p className="text-sm font-medium">{notification.title}</p>
                    <span className="text-xs text-gray-400">
                      {formatNotificationTime(notification.timestamp)}
                    </span>
                  </div>
                  <p className="text-sm text-gray-300 mb-2">{notification.message}</p>
                  {!notification.read && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="bg-gray-700 text-gray-200 border-gray-600 hover:bg-gray-600 hover:text-white"
                      onClick={() => handleMarkAsRead(notification.id)}
                    >
                      Mark as read
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
