import { Link } from "wouter";

export function Logo() {
  return (
    <Link href="/">
      <div className="flex items-center">
        <span className="font-bold text-xl text-blue-400">BetWinner</span>
        <span className="text-sm ml-1 text-gray-300">Sub-Agent</span>
      </div>
    </Link>
  );
}
