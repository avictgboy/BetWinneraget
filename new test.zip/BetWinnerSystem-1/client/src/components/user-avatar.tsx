import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface UserAvatarProps {
  onClick?: () => void;
}

export function UserAvatar({ onClick }: UserAvatarProps) {
  const { user } = useAuth();

  const getInitials = () => {
    if (!user) return "?";
    if (user.fullName) {
      return user.fullName
        .split(" ")
        .map(name => name[0])
        .join("")
        .toUpperCase()
        .substring(0, 2);
    }
    return user.username.substring(0, 2).toUpperCase();
  };

  return (
    <button 
      type="button" 
      className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center hover:ring-2 hover:ring-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-400 transition-all"
      onClick={onClick}
    >
      <Avatar className="h-8 w-8 border-2 border-gray-700">
        <AvatarFallback className="text-sm font-medium bg-blue-600 text-white">
          {getInitials()}
        </AvatarFallback>
      </Avatar>
    </button>
  );
}
