import { ReactNode } from "react";
import { ThemeProvider as NextThemesProvider } from "next-themes";
import { AuthProvider } from "@/hooks/use-auth";
import { CurrencyProvider } from "@/hooks/use-currency";
import { WebSocketProvider } from "@/hooks/use-websocket";

export function ThemeProvider({ children }: { children: ReactNode }) {
  return (
    <NextThemesProvider attribute="class" defaultTheme="light" enableSystem>
      <AuthProvider>
        <CurrencyProvider>
          <WebSocketProvider>
            {children}
          </WebSocketProvider>
        </CurrencyProvider>
      </AuthProvider>
    </NextThemesProvider>
  );
}
