import { useLocation } from "wouter";
import { Home, Wallet, Users, CheckSquare } from "lucide-react";
import { cn } from "@/lib/utils";

export default function MobileNav() {
  const [location, setLocation] = useLocation();

  const navItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/add-funds", label: "Add Funds", icon: Wallet },
    { href: "/players", label: "Players", icon: Users },
    { href: "/commissions", label: "Commissions", icon: CheckSquare },
  ];

  return (
    <nav className="fixed bottom-0 left-0 w-full bg-white shadow-lg border-t border-gray-200 z-30 lg:hidden">
      <div className="flex justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          
          return (
            <a
              key={item.href}
              href={item.href}
              onClick={(e) => {
                e.preventDefault();
                setLocation(item.href);
              }}
              className={cn(
                "flex flex-col items-center justify-center py-3",
                isActive ? "text-primary-600" : "text-gray-500"
              )}
            >
              <Icon className="h-6 w-6" />
              <span className="text-xs mt-1">{item.label}</span>
            </a>
          );
        })}
      </div>
    </nav>
  );
}
