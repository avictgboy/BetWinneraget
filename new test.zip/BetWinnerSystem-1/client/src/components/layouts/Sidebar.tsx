import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { 
  Home, 
  Wallet, 
  Users, 
  CheckSquare, 
  Share2, 
  MessageSquare,
  LogOut
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function Sidebar() {
  const { user, logoutMutation } = useAuth();
  const [location, setLocation] = useLocation();

  if (!user) return null;

  const navItems = [
    { href: "/", label: "Dashboard", icon: Home },
    { href: "/add-funds", label: "Add Funds", icon: Wallet },
    { href: "/players", label: "Player Management", icon: Users },
    { href: "/commissions", label: "Commissions", icon: CheckSquare },
    { href: "/affiliate", label: "Affiliate Program", icon: Share2 },
    { href: "/support", label: "Support Chat", icon: MessageSquare },
  ];

  const handleLogout = () => {
    logoutMutation.mutate();
    setLocation('/auth');
  };

  return (
    <aside className="fixed left-0 top-0 w-60 h-full bg-white shadow-lg pt-16 z-20 transform -translate-x-full lg:translate-x-0 transition-transform duration-300" id="sidebar">
      <div className="px-4 py-6">
        <div className="pb-4 border-b border-gray-200">
          <p className="text-sm text-gray-500">Sub-Agent ID:</p>
          <p className="font-mono text-sm font-medium">{user.agentId}</p>
        </div>
        
        <nav className="mt-6 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            
            return (
              <a 
                key={item.href}
                href={item.href}
                onClick={(e) => {
                  e.preventDefault();
                  setLocation(item.href);
                  // Close sidebar on mobile when an item is clicked
                  if (window.innerWidth < 1024) {
                    const sidebar = document.getElementById('sidebar');
                    if (sidebar) {
                      sidebar.classList.add('-translate-x-full');
                    }
                  }
                }}
                className={cn(
                  "flex items-center px-4 py-3 text-sm rounded-lg",
                  isActive 
                    ? "text-primary-600 bg-primary-50 font-medium" 
                    : "text-gray-700 hover:bg-gray-100"
                )}
              >
                <Icon className="h-5 w-5 mr-3" />
                {item.label}
              </a>
            );
          })}
        </nav>
      </div>
      
      <div className="absolute bottom-0 w-full px-4 py-6 border-t border-gray-200">
        <button
          onClick={handleLogout}
          className="flex items-center text-sm text-gray-700 hover:text-primary-600 w-full"
        >
          <LogOut className="h-5 w-5 mr-3" />
          Logout
        </button>
      </div>
    </aside>
  );
}
