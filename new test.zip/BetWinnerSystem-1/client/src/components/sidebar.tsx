import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  Home, 
  Wallet, 
  Users, 
  ClipboardCheck, 
  MessageSquare,
  LogOut,
  FileCheck,
  ShieldCheck,
  Settings,
  CreditCard,
  MessageCircle,
  ArrowRightLeft,
  CircleDollarSign,
  History,
  BarChart3
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

interface SidebarProps {
  isOpen: boolean;
}

export function Sidebar({ isOpen }: SidebarProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const isActive = (path: string) => location === path;
  const isAdmin = user?.role === "admin";

  // Updated navigation items based on requirements
  const agentNavItems = [
    {
      path: "/",
      label: "Dashboard",
      icon: Home,
    },
    {
      path: "/add-funds",
      label: "Add Funds",
      icon: Wallet,
    },
    {
      path: "/remittance",
      label: "Remittance",
      icon: ArrowRightLeft,
    },
    {
      path: "/transactions",
      label: "Transaction History",
      icon: History,
    },
    {
      path: "/player-management",
      label: "Player Management",
      icon: Users,
    },
    {
      path: "/commissions",
      label: "Commissions",
      icon: ClipboardCheck,
    },
    {
      path: "/chat",
      label: "Live Chat",
      icon: MessageCircle,
    },
    {
      path: "/support",
      label: "Support",
      icon: MessageSquare,
    },
  ];

  // Updated admin items to match requirements
  const adminNavItems = [
    {
      path: "/admin/transactions",
      label: "Pending Transactions",
      icon: FileCheck,
    },
    {
      path: "/admin/transactions-history",
      label: "Transaction History",
      icon: BarChart3,
    },
    {
      path: "/admin/remittance",
      label: "Remittance Admin",
      icon: CircleDollarSign,
    },
    {
      path: "/admin/users",
      label: "User Management",
      icon: ShieldCheck,
    },
    {
      path: "/admin/commission-settings",
      label: "Commission Settings",
      icon: Settings,
    },
    {
      path: "/admin/payment-methods",
      label: "Payment Methods",
      icon: CreditCard,
    },
  ];

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <aside className={`fixed left-0 top-0 w-64 h-full bg-gray-800 shadow-lg pt-16 z-20 transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 transition-transform duration-300 overflow-y-auto`}>
      <div className="px-4 py-6">
        <div className="pb-4 border-b border-gray-700">
          <p className="text-sm text-gray-400">
            {isAdmin ? 'Admin' : 'Sub-Agent'} ID:
          </p>
          <p className="font-mono text-sm font-medium text-gray-200">
            {user?.agentId || 'N/A'}
          </p>
          {isAdmin && (
            <div className="mt-2">
              <span className="inline-flex items-center rounded-full bg-blue-900 px-2 py-1 text-xs font-medium text-blue-200 ring-1 ring-inset ring-blue-500/30">
                <ShieldCheck className="mr-1 h-3 w-3" /> Admin Access
              </span>
            </div>
          )}
        </div>
        
        <nav className="mt-6 space-y-1">
          {/* Agent Navigation */}
          {agentNavItems.map((item) => (
            <Link
              key={item.path}
              href={item.path}
              className={`flex items-center px-4 py-3 text-sm rounded-lg ${
                isActive(item.path)
                  ? "text-blue-400 bg-gray-700 font-medium"
                  : "text-gray-300 hover:bg-gray-700 hover:text-gray-100"
              }`}
            >
              <item.icon className="h-5 w-5 mr-3 flex-shrink-0" />
              <span className="truncate">{item.label}</span>
            </Link>
          ))}

          {/* Admin Navigation */}
          {isAdmin && (
            <div className="pt-4">
              <div className="flex items-center py-2">
                <Separator className="flex-grow bg-gray-700" />
                <span className="mx-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Admin
                </span>
                <Separator className="flex-grow bg-gray-700" />
              </div>
              
              {adminNavItems.map((item) => (
                <Link
                  key={item.path}
                  href={item.path}
                  className={`flex items-center px-4 py-3 text-sm rounded-lg ${
                    isActive(item.path)
                      ? "text-blue-300 bg-gray-700 font-medium"
                      : "text-gray-300 hover:bg-gray-700 hover:text-gray-100"
                  }`}
                >
                  <item.icon className="h-5 w-5 mr-3 flex-shrink-0" />
                  <span className="truncate">{item.label}</span>
                </Link>
              ))}
            </div>
          )}
        </nav>
      </div>
      
      <div className="sticky bottom-0 w-full px-4 py-6 border-t border-gray-700 bg-gray-800 mt-10">
        <Button 
          variant="ghost" 
          className="flex items-center w-full justify-start text-gray-300 hover:text-gray-100 hover:bg-gray-700"
          onClick={handleLogout}
          disabled={logoutMutation.isPending}
        >
          <LogOut className="h-5 w-5 mr-3 flex-shrink-0" />
          <span className="text-sm">Logout</span>
        </Button>
      </div>
    </aside>
  );
}
