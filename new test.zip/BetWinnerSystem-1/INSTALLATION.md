# BetWinner Hosting Update Package

## Overview

This update package contains enhanced database support for the BetWinner platform, especially optimized for shared hosting environments. It includes improved error handling, connection diagnostics, and fallback mechanisms to ensure your application runs smoothly even in challenging hosting environments.

## What's Included

1. Enhanced database connection with support for both PostgreSQL and MySQL
2. Improved error handling with detailed diagnostics
3. Automatic fallback to memory store if database is unavailable
4. Comprehensive troubleshooting guide for hosting environments
5. Database connection test utility

## Installation Instructions

### For cPanel/WHM Shared Hosting

1. **Upload Files**
   - Upload this zip file to your hosting account
   - Extract the contents to a temporary directory

2. **Replace Server Files**
   - Copy these files to your application's server directory, replacing the existing files:
     - `db.ts`
     - `database-storage.ts`
     - `storage.ts`
     - Any other server/*.ts files included in this package

3. **Add Support Files**
   - Copy these files to your application's root directory:
     - `database-connection-test.ts`
     - `TROUBLESHOOTING_GUIDE.md`

4. **Update Environment Settings**
   - Add these environment variables to your .env file:
     ```
     # For MySQL on shared hosting:
     DB_TYPE=mysql
     DATABASE_URL=mysql://username:password@localhost:3306/database_name
     ```
   - Replace username, password, and database_name with your actual MySQL credentials
   - Note: On some shared hosts, you may need to use your cPanel username as a prefix for the database name

5. **Rebuild the Application**
   - Run: `npm run build`

6. **Test Database Connection**
   - Run: `npm run tsx database-connection-test.ts`
   - Follow any troubleshooting steps if connection issues occur

### For Dedicated/VPS Servers

1. **Update Files**
   - Replace the server files with the ones in this package
   - Add the support files to your root directory

2. **Configure Database**
   - For PostgreSQL (default):
     ```
     DB_TYPE=postgres
     DATABASE_URL=postgres://username:password@hostname:5432/database_name
     ```
   - For MySQL:
     ```
     DB_TYPE=mysql
     DATABASE_URL=mysql://username:password@hostname:3306/database_name
     ```

3. **Restart Your Application**
   - After updating files and environment variables, restart your application

## Troubleshooting

If you encounter any issues with the database connection:

1. First, run the diagnostic utility:
   ```
   npm run tsx database-connection-test.ts
   ```

2. Refer to the included `TROUBLESHOOTING_GUIDE.md` for detailed solutions to common problems

3. Check your database credentials and connection string format

4. On shared hosting, verify:
   - Your database user has the correct permissions
   - Remote MySQL access is enabled in cPanel (if needed)
   - Database naming convention includes cPanel username prefix if required

## Production Failover Mode

In production environments (NODE_ENV=production), the application will automatically fall back to an in-memory database if it cannot connect to the configured database. This ensures your application remains functional while you resolve connection issues.

Note: Data stored in memory will be lost when the application restarts, so this is only intended as a temporary solution.

## Contact Support

If you continue to experience issues after following the troubleshooting guide, please contact support with:

1. The exact error message from database-connection-test.ts
2. Your hosting provider details
3. Any specific steps you've taken to resolve the issue
