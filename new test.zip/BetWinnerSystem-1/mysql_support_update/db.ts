import { Pool as PgPool, neonConfig } from '@neondatabase/serverless';
import { drizzle as drizzleNeon } from 'drizzle-orm/neon-serverless';
import mysql from 'mysql2/promise';
import { drizzle as drizzleMysql } from 'drizzle-orm/mysql2';
import ws from "ws";
import * as schema from "@shared/schema";

// Check database connection type from environment
const dbType = process.env.DB_TYPE || 'postgres';

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Use the appropriate database client based on the DB_TYPE
let db;

if (dbType === 'mysql') {
  // MySQL connection
  console.log('Using MySQL database connection');
  const pool = mysql.createPool(process.env.DATABASE_URL);
  db = drizzleMysql(pool, { schema, mode: 'default' });
} else {
  // PostgreSQL connection (default)
  console.log('Using PostgreSQL database connection');
  // Required for Neon serverless
  neonConfig.webSocketConstructor = ws;
  const pool = new PgPool({ connectionString: process.env.DATABASE_URL });
  db = drizzleNeon(pool, { schema });
}

export { db };