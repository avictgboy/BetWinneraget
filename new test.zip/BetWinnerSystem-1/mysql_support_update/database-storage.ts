import { db } from "./db";
import { Pool } from '@neondatabase/serverless';
import mysql from 'mysql2/promise';
import session from "express-session";
import memorystore from 'memorystore';
import connectPgSimple from 'connect-pg-simple';
import { 
  users, type User, type InsertUser,
  topupTransactions, players, playerTransactions,
  commissions, supportTickets, supportMessages,
  withdrawalTransactions, type WithdrawalTransaction,
  remittanceFees, type RemittanceFee, type InsertRemittanceFee,
  remittanceTransactions, type RemittanceTransaction, type InsertRemittanceTransaction
} from "@shared/schema";
import { eq, and, desc, gte, lte, count, or } from "drizzle-orm";
import { v4 as uuidv4 } from 'uuid';
import { IStorage, TopUpRequest, WithdrawalRequest, RemittanceRequest } from "./storage";

// Create session store factories
const MemoryStore = memorystore(session);
const PostgresSessionStore = connectPgSimple(session);

export class DatabaseStorage implements IStorage {
  sessionStore: any; // Using any for better compatibility

  constructor() {
    // Check database type
    const dbType = process.env.DB_TYPE || 'postgres';
    
    if (dbType === 'postgres') {
      // Set up PostgreSQL session store
      try {
        // Create a new Postgres pool for sessions
        const pgPool = new Pool({ connectionString: process.env.DATABASE_URL });
        
        this.sessionStore = new PostgresSessionStore({
          pool: pgPool,
          createTableIfMissing: true,
          tableName: 'sessions'
        });
      } catch (error) {
        console.error('Error setting up PostgreSQL session store:', error);
        // Fallback to memory store if PostgreSQL session store fails
        this.sessionStore = new MemoryStore({});
      }
    } else {
      // For MySQL, use memory store for simplicity in this implementation
      // In a production app, you would use a MySQL-compatible session store
      this.sessionStore = new MemoryStore({});
    }
  }
  
  // Remittance Fee Operations
  async getRemittanceFees(): Promise<RemittanceFee[]> {
    return await db.select().from(remittanceFees).orderBy(desc(remittanceFees.createdAt));
  }
  
  async getRemittanceFeeById(id: number): Promise<RemittanceFee | undefined> {
    const [fee] = await db.select().from(remittanceFees).where(eq(remittanceFees.id, id));
    return fee;
  }
  
  async createRemittanceFee(data: InsertRemittanceFee): Promise<RemittanceFee> {
    const [fee] = await db.insert(remittanceFees).values(data).returning();
    return fee;
  }
  
  async updateRemittanceFee(id: number, data: Partial<RemittanceFee>): Promise<RemittanceFee | undefined> {
    const [updatedFee] = await db.update(remittanceFees)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(eq(remittanceFees.id, id))
      .returning();
    
    return updatedFee;
  }
  
  async deleteRemittanceFee(id: number): Promise<boolean> {
    try {
      await db.delete(remittanceFees).where(eq(remittanceFees.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting remittance fee:", error);
      return false;
    }
  }
  
  // Remittance Transaction Operations
  async createRemittanceRequest(agentId: number, data: RemittanceRequest): Promise<RemittanceTransaction> {
    const user = await this.getUser(agentId);
    if (!user) {
      throw new Error("Agent not found");
    }
    
    // Check if agent has sufficient balance
    const requestAmount = data.amount;
    if (Number(user.balance) < requestAmount) {
      throw new Error("Insufficient balance for remittance");
    }
    
    // Calculate fee based on channel and amount
    // Find appropriate fee based on channel and amount
    console.log(`Finding fee for channel ${data.recipientChannel} and amount ${requestAmount}`);
    
    // First get all active fees for this channel
    const channelFees = await db.select()
      .from(remittanceFees)
      .where(and(
        eq(remittanceFees.channel, data.recipientChannel),
        eq(remittanceFees.active, true)
      ));
    
    console.log(`Found ${channelFees.length} active fees for this channel`);
    
    // Then manually filter by amount ranges
    const fees = channelFees.filter(fee => {
      const minAmount = fee.minAmount ? Number(fee.minAmount) : 0;
      const maxAmount = fee.maxAmount ? Number(fee.maxAmount) : Number.MAX_SAFE_INTEGER;
      
      return requestAmount >= minAmount && requestAmount <= maxAmount;
    });
    
    console.log(`After filtering by amount range, found ${fees.length} applicable fees`);
    
    // Calculate fee
    let feeAmount = 0;
    let feeId = null;
    
    if (fees.length > 0) {
      const fee = fees[0];
      feeId = fee.id;
      
      if (fee.feeType === "flat") {
        feeAmount = Number(fee.flatFee);
      } else if (fee.feeType === "percentage") {
        feeAmount = (Number(fee.percentageFee) / 100) * requestAmount;
      } else if (fee.feeType === "hybrid") {
        feeAmount = Number(fee.flatFee) + ((Number(fee.percentageFee) / 100) * requestAmount);
      }
    }
    
    // Total amount is the request amount plus the fee
    const totalAmount = requestAmount + feeAmount;
    
    // Deduct from user's balance
    const newBalance = Number(user.balance) - totalAmount;
    await this.updateUser(agentId, { balance: newBalance.toString() });
    
    // Create transaction record
    const [transaction] = await db.insert(remittanceTransactions)
      .values({
        agentId,
        recipientChannel: data.recipientChannel,
        recipientName: data.recipientName,
        recipientAccount: data.recipientAccount,
        recipientAdditionalInfo: data.recipientAdditionalInfo || null,
        amount: requestAmount.toString(),
        feeId: feeId,
        feeAmount: feeAmount.toString(),
        totalAmount: totalAmount.toString(),
        status: "pending",
        notes: data.notes || null
      })
      .returning();
    
    return transaction;
  }
  
  async getRemittanceTransactionsByAgentId(agentId: number): Promise<RemittanceTransaction[]> {
    return await db.select()
      .from(remittanceTransactions)
      .where(eq(remittanceTransactions.agentId, agentId))
      .orderBy(desc(remittanceTransactions.createdAt));
  }
  
  async getPendingRemittanceTransactions(): Promise<RemittanceTransaction[]> {
    console.log("Fetching pending remittance transactions");
    const transactions = await db.select()
      .from(remittanceTransactions)
      .where(eq(remittanceTransactions.status, "pending"))
      .orderBy(desc(remittanceTransactions.createdAt));
    
    console.log(`Found ${transactions.length} pending transactions`);
    
    // Fetch related agent information for each transaction
    return await Promise.all(transactions.map(async (tx) => {
      const [agent] = await db.select({
        id: users.id,
        username: users.username,
        fullName: users.fullName,
        email: users.email,
        phone: users.phone,
        balance: users.balance,
        role: users.role
      })
      .from(users)
      .where(eq(users.id, tx.agentId));
      
      // Fetch fee information if feeId is available
      let feeDetails = null;
      if (tx.feeId) {
        try {
          const [fee] = await db.select()
            .from(remittanceFees)
            .where(eq(remittanceFees.id, tx.feeId));
          
          feeDetails = fee;
          console.log(`Found fee details for transaction ${tx.id}:`, feeDetails);
        } catch (error) {
          console.error(`Error fetching fee details for transaction ${tx.id}:`, error);
        }
      } else {
        console.log(`Transaction ${tx.id} has no feeId`);
      }
      
      return {
        ...tx,
        agentUsername: agent ? agent.username : `Agent-${tx.agentId}`,
        agentFullName: agent ? agent.fullName : null,
        agentEmail: agent ? agent.email : null,
        agentPhone: agent ? agent.phone : null,
        agentBalance: agent ? agent.balance : null,
        agentRole: agent ? agent.role : null,
        feeDetails: feeDetails // Adding fee details to the response
      };
    }));
  }
  
  async approveRemittanceTransaction(
    transactionId: number, 
    approve: boolean, 
    reason: string, 
    adminId: number,
    transactionNumber?: string
  ): Promise<RemittanceTransaction> {
    // Begin transaction
    return await db.transaction(async (tx) => {
      // Get the transaction
      const [remittanceTx] = await tx.select()
        .from(remittanceTransactions)
        .where(eq(remittanceTransactions.id, transactionId));
      
      if (!remittanceTx) {
        throw new Error("Remittance transaction not found");
      }
      
      if (remittanceTx.status !== "pending") {
        throw new Error("Transaction is not in pending status");
      }
      
      // Get the agent
      const [agent] = await tx.select()
        .from(users)
        .where(eq(users.id, remittanceTx.agentId));
      
      if (!agent) {
        throw new Error("Agent not found");
      }
      
      if (approve) {
        // Generate a transaction number if not provided
        const txNumber = transactionNumber || 
          `TRX-${Date.now().toString().slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`;
        
        // Update transaction status to approved
        const [updatedTx] = await tx.update(remittanceTransactions)
          .set({
            status: "approved",
            statusReason: reason || "Approved by admin",
            processedById: adminId,
            processedAt: new Date(),
            transactionNumber: txNumber,
            updatedAt: new Date()
          })
          .where(eq(remittanceTransactions.id, transactionId))
          .returning();
        
        return updatedTx;
      } else {
        // Rejected transaction - refund the amount to the agent
        const refundAmount = Number(remittanceTx.totalAmount);
        const newBalance = Number(agent.balance) + refundAmount;
        
        // Update agent balance
        await tx.update(users)
          .set({ balance: newBalance.toString() })
          .where(eq(users.id, remittanceTx.agentId));
        
        // Update transaction status to rejected
        const [updatedTx] = await tx.update(remittanceTransactions)
          .set({
            status: "rejected",
            statusReason: reason || "Rejected by admin",
            processedById: adminId,
            processedAt: new Date(),
            updatedAt: new Date()
          })
          .where(eq(remittanceTransactions.id, transactionId))
          .returning();
        
        return updatedTx;
      }
    });
  }
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values({
      ...insertUser,
      agentId: insertUser.agentId || uuidv4().slice(0, 8),
      promoCode: insertUser.promoCode || `BW${Math.floor(10000 + Math.random() * 90000)}`,
      balance: insertUser.balance || "0"
    }).returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    // Make sure balance is a string if provided
    if (userData.balance !== undefined && typeof userData.balance === 'number') {
      userData.balance = userData.balance.toString();
    }
    
    const [updatedUser] = await db.update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    
    return updatedUser;
  }

  // Top-up transactions
  async createTopupRequest(userId: number, data: TopUpRequest): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }

    const conversionRate = 125.45; // In a real app, this would come from an external service
    const convertedAmount = data.amount * conversionRate;

    const [transaction] = await db.insert(topupTransactions).values({
      userId,
      amount: data.amount.toString(),
      currency: data.currency,
      convertedAmount: convertedAmount.toString(),
      conversionRate: conversionRate.toString(),
      paymentMethod: data.paymentMethod,
      walletAddress: data.walletAddress || null,
      accountNumber: data.accountNumber || null,
      bankDetails: data.bankDetails || null,
      transactionId: data.transactionId || null,
      status: "pending"
    }).returning();

    // Update user's balance
    const newBalance = Number(user.balance) + convertedAmount;
    await this.updateUser(userId, { balance: newBalance.toString() });

    return {
      ...transaction,
      amount: Number(transaction.amount),
      convertedAmount: Number(transaction.convertedAmount),
      conversionRate: Number(transaction.conversionRate)
    };
  }
  
  // Withdrawal requests
  async createWithdrawalRequest(userId: number, data: WithdrawalRequest): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }

    // Check if user has sufficient balance
    if (Number(user.balance) < data.amount) {
      throw new Error("Insufficient balance for withdrawal");
    }

    // Create a withdrawal transaction
    const [transaction] = await db.insert(withdrawalTransactions).values({
      userId,
      amount: data.amount.toString(),
      withdrawalMethod: data.withdrawalMethod,
      accountNumber: data.accountNumber || null,
      walletAddress: data.walletAddress || null,
      bankDetails: data.bankDetails || null,
      status: "pending",
      reference: `WD-${Date.now().toString().slice(-6)}`
    }).returning();

    // Deduct from user's balance immediately
    const newBalance = Number(user.balance) - data.amount;
    await this.updateUser(userId, { balance: newBalance.toString() });

    return {
      ...transaction,
      amount: Number(transaction.amount)
    };
  }

  async getTransactionsByUserId(userId: number, filters?: {
    startDate?: Date;
    endDate?: Date;
    type?: string[];
    status?: string[];
    search?: string;
  }): Promise<any[]> {
    try {
      console.log(`Getting transactions for user ${userId} with filters:`, filters);
      
      // Get top-up transactions
      const topupTxs = await db.select().from(topupTransactions)
        .where(eq(topupTransactions.userId, userId))
        .orderBy(desc(topupTransactions.createdAt));
      
      // Get withdrawal transactions
      const withdrawalTxs = await db.select().from(withdrawalTransactions)
        .where(eq(withdrawalTransactions.userId, userId))
        .orderBy(desc(withdrawalTransactions.createdAt));
      
      // Get player transactions
      const playerTxs = await db.select().from(playerTransactions)
        .where(eq(playerTransactions.agentId, userId))
        .orderBy(desc(playerTransactions.createdAt));
      
      // Get remittance transactions
      const remittanceTxs = await db.select().from(remittanceTransactions)
        .where(eq(remittanceTransactions.agentId, userId))
        .orderBy(desc(remittanceTransactions.createdAt));
      
      // Format top-up transactions with a prefix to ensure unique keys
      const formattedTopups = topupTxs.map(tx => ({
        id: `topup-${tx.id}`,
        originalId: tx.id,
        type: "USDT Top-up",
        transactionType: "topup",
        amount: Number(tx.amount),
        currency: tx.currency,
        convertedAmount: tx.convertedAmount ? Number(tx.convertedAmount) : undefined,
        date: new Date(tx.createdAt).toLocaleDateString(),
        time: new Date(tx.createdAt).toLocaleTimeString(),
        timestamp: new Date(tx.createdAt).toISOString(),
        status: tx.status,
        paymentMethod: tx.paymentMethod,
        walletAddress: tx.walletAddress,
        accountNumber: tx.accountNumber,
        bankDetails: tx.bankDetails,
        transactionId: tx.transactionId,
        userId: tx.userId,
        createdAt: tx.createdAt
      }));
      
      // Format withdrawal transactions with a prefix to ensure unique keys
      const formattedWithdrawals = withdrawalTxs.map(tx => ({
        id: `withdrawal-${tx.id}`,
        originalId: tx.id,
        type: "Withdrawal",
        transactionType: "withdrawal",
        amount: Number(tx.amount),
        currency: "BDT",
        method: tx.withdrawalMethod,
        accountNumber: tx.accountNumber,
        walletAddress: tx.walletAddress,
        bankDetails: tx.bankDetails,
        reference: tx.reference,
        date: new Date(tx.createdAt).toLocaleDateString(),
        time: new Date(tx.createdAt).toLocaleTimeString(),
        timestamp: new Date(tx.createdAt).toISOString(),
        status: tx.status,
        statusReason: tx.statusReason,
        userId: tx.userId,
        createdAt: tx.createdAt
      }));
      
      // Format player transactions with a prefix to ensure unique keys
      const formattedPlayerTxs = playerTxs.map(tx => ({
        id: `player-${tx.id}`,
        originalId: tx.id,
        type: tx.type === "deposit" ? "Player Deposit" : "Player Withdrawal",
        transactionType: tx.type === "deposit" ? "player_deposit" : "player_withdrawal",
        amount: Number(tx.amount),
        currency: "BDT",
        playerId: tx.playerId,
        paymentCode: tx.paymentCode,
        date: new Date(tx.createdAt).toLocaleDateString(),
        time: new Date(tx.createdAt).toLocaleTimeString(),
        timestamp: new Date(tx.createdAt).toISOString(),
        status: tx.status,
        statusReason: tx.statusReason || undefined,
        commissionAmount: tx.commissionAmount ? Number(tx.commissionAmount) : undefined,
        agentId: tx.agentId,
        createdAt: tx.createdAt
      }));
      
      // Format remittance transactions
      const formattedRemittanceTxs = remittanceTxs.map(tx => ({
        id: `remittance-${tx.id}`,
        originalId: tx.id,
        type: "Remittance",
        transactionType: "remittance",
        amount: Number(tx.amount),
        feeAmount: tx.feeAmount ? Number(tx.feeAmount) : 0,
        totalAmount: tx.totalAmount ? Number(tx.totalAmount) : Number(tx.amount),
        currency: "BDT",
        recipientChannel: tx.recipientChannel,
        recipientName: tx.recipientName,
        recipientAccount: tx.recipientAccount,
        transactionNumber: tx.transactionNumber,
        date: new Date(tx.createdAt).toLocaleDateString(),
        time: new Date(tx.createdAt).toLocaleTimeString(),
        timestamp: new Date(tx.createdAt).toISOString(),
        status: tx.status,
        statusReason: tx.statusReason,
        agentId: tx.agentId,
        notes: tx.notes,
        createdAt: tx.createdAt
      }));
      
      // Combine all transaction types
      let allTransactions = [
        ...formattedTopups, 
        ...formattedWithdrawals, 
        ...formattedPlayerTxs,
        ...formattedRemittanceTxs
      ];
      
      // Apply filters if provided
      if (filters) {
        // Filter by date range
        if (filters.startDate) {
          allTransactions = allTransactions.filter(tx => 
            new Date(tx.createdAt) >= new Date(filters.startDate!)
          );
        }
        
        if (filters.endDate) {
          allTransactions = allTransactions.filter(tx => 
            new Date(tx.createdAt) <= new Date(filters.endDate!)
          );
        }
        
        // Filter by transaction type
        if (filters.type && filters.type.length > 0) {
          allTransactions = allTransactions.filter(tx => 
            filters.type!.includes(tx.transactionType)
          );
        }
        
        // Filter by status
        if (filters.status && filters.status.length > 0) {
          allTransactions = allTransactions.filter(tx => 
            filters.status!.includes(tx.status)
          );
        }
        
        // Search functionality
        if (filters.search) {
          const searchTerm = filters.search.toLowerCase();
          allTransactions = allTransactions.filter(tx => {
            // Search in different fields based on transaction type
            const searchFields = [
              tx.id,
              tx.type,
              tx.status,
              tx.amount.toString(),
              tx.date,
              tx.time
            ];
            
            // Add transaction-specific fields
            if (tx.transactionType === 'topup') {
              searchFields.push(
                tx.paymentMethod || '',
                tx.transactionId || ''
              );
            } else if (tx.transactionType === 'withdrawal') {
              searchFields.push(
                tx.method || '',
                tx.reference || ''
              );
            } else if (tx.transactionType === 'player_deposit' || tx.transactionType === 'player_withdrawal') {
              searchFields.push(
                tx.playerId || '',
                tx.paymentCode || ''
              );
            } else if (tx.transactionType === 'remittance') {
              searchFields.push(
                tx.recipientName || '',
                tx.recipientAccount || '',
                tx.recipientChannel || '',
                tx.transactionNumber || ''
              );
            }
            
            // Check if any field contains the search term
            return searchFields.some(field => 
              field?.toLowerCase().includes(searchTerm)
            );
          });
        }
      }
      
      // Sort by date (newest first)
      return allTransactions.sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
    } catch (error) {
      console.error("Error in getTransactionsByUserId:", error);
      throw error;
    }
  }
  
  // Get pending transactions for admin approval
  async getPendingTransactions(): Promise<any[]> {
    try {
      // Get pending player transactions
      const pendingPlayerTxs = await db.select().from(playerTransactions)
        .where(eq(playerTransactions.status, "pending"))
        .orderBy(desc(playerTransactions.createdAt));
      
      // Get pending topup transactions
      const pendingTopupTxs = await db.select().from(topupTransactions)
        .where(eq(topupTransactions.status, "pending"))
        .orderBy(desc(topupTransactions.createdAt));
      
      // Format player transactions
      const formattedPlayerTxs = await Promise.all(pendingPlayerTxs.map(async tx => {
        const [agent] = await db.select().from(users)
          .where(eq(users.id, tx.agentId));
          
        return {
          id: `player-${tx.id}`,
          originalId: tx.id,
          type: tx.type,
          txType: "player",
          playerId: tx.playerId,
          amount: Number(tx.amount),
          paymentCode: tx.paymentCode,
          date: new Date(tx.createdAt).toLocaleDateString(),
          time: new Date(tx.createdAt).toLocaleTimeString(),
          status: tx.status,
          agentId: tx.agentId,
          agentUsername: agent ? agent.username : `Agent-${tx.agentId}`,
          commissionAmount: tx.commissionAmount ? Number(tx.commissionAmount) : undefined,
        };
      }));
      
      // Format topup transactions
      const formattedTopupTxs = await Promise.all(pendingTopupTxs.map(async tx => {
        const [user] = await db.select().from(users)
          .where(eq(users.id, tx.userId));
          
        return {
          id: `topup-${tx.id}`,
          originalId: tx.id,
          type: "topup",
          txType: "agent_topup",
          amount: Number(tx.amount),
          currency: tx.currency,
          convertedAmount: tx.convertedAmount ? Number(tx.convertedAmount) : undefined,
          date: new Date(tx.createdAt).toLocaleDateString(),
          time: new Date(tx.createdAt).toLocaleTimeString(),
          status: tx.status,
          userId: tx.userId,
          username: user ? user.username : `User-${tx.userId}`,
          paymentMethod: tx.paymentMethod,
          walletAddress: tx.walletAddress,
          accountNumber: tx.accountNumber,
          bankDetails: tx.bankDetails,
          transactionId: tx.transactionId,
        };
      }));
      
      // Combine all pending transactions and sort by date (newest first)
      return [...formattedPlayerTxs, ...formattedTopupTxs].sort((a, b) => 
        new Date(b.date + ' ' + b.time).getTime() - new Date(a.date + ' ' + a.time).getTime()
      );
    } catch (error) {
      console.error("Error in getPendingTransactions:", error);
      throw error;
    }
  }
  
  // Get all transactions for admin view
  async getAllTransactions(filters?: {
    startDate?: Date;
    endDate?: Date;
    type?: string[];
    status?: string[];
    search?: string;
    agentId?: number;
    playerId?: string;
  }): Promise<any[]> {
    try {
      console.log("Getting all transactions with filters:", filters);
      
      // Get all top-up transactions
      const topupTxs = await db.select({
        id: topupTransactions.id,
        userId: topupTransactions.userId,
        amount: topupTransactions.amount,
        currency: topupTransactions.currency,
        convertedAmount: topupTransactions.convertedAmount,
        conversionRate: topupTransactions.conversionRate,
        paymentMethod: topupTransactions.paymentMethod,
        walletAddress: topupTransactions.walletAddress,
        accountNumber: topupTransactions.accountNumber,
        bankDetails: topupTransactions.bankDetails,
        transactionId: topupTransactions.transactionId,
        status: topupTransactions.status,
        statusReason: topupTransactions.statusReason,
        processedById: topupTransactions.processedById,
        processedAt: topupTransactions.processedAt,
        createdAt: topupTransactions.createdAt,
        updatedAt: topupTransactions.updatedAt,
        // Join user data
        username: users.username,
        fullName: users.fullName,
        email: users.email,
        phone: users.phone
      })
      .from(topupTransactions)
      .leftJoin(users, eq(topupTransactions.userId, users.id))
      .orderBy(desc(topupTransactions.createdAt));
      
      // Get all withdrawal transactions
      const withdrawalTxs = await db.select({
        id: withdrawalTransactions.id,
        userId: withdrawalTransactions.userId,
        amount: withdrawalTransactions.amount,
        withdrawalMethod: withdrawalTransactions.withdrawalMethod,
        accountNumber: withdrawalTransactions.accountNumber,
        walletAddress: withdrawalTransactions.walletAddress,
        bankDetails: withdrawalTransactions.bankDetails,
        reference: withdrawalTransactions.reference,
        status: withdrawalTransactions.status,
        statusReason: withdrawalTransactions.statusReason,
        processedById: withdrawalTransactions.processedById,
        processedAt: withdrawalTransactions.processedAt,
        createdAt: withdrawalTransactions.createdAt,
        updatedAt: withdrawalTransactions.updatedAt,
        // Join user data
        username: users.username,
        fullName: users.fullName,
        email: users.email,
        phone: users.phone
      })
      .from(withdrawalTransactions)
      .leftJoin(users, eq(withdrawalTransactions.userId, users.id))
      .orderBy(desc(withdrawalTransactions.createdAt));
      
      // Get all player transactions
      const playerTxs = await db.select({
        id: playerTransactions.id,
        agentId: playerTransactions.agentId,
        playerId: playerTransactions.playerId,
        type: playerTransactions.type,
        amount: playerTransactions.amount,
        paymentCode: playerTransactions.paymentCode,
        status: playerTransactions.status,
        statusReason: playerTransactions.statusReason,
        processedById: playerTransactions.processedById,
        processedAt: playerTransactions.processedAt,
        commissionAmount: playerTransactions.commissionAmount,
        createdAt: playerTransactions.createdAt,
        updatedAt: playerTransactions.updatedAt,
        // Join agent data
        username: users.username,
        fullName: users.fullName,
        email: users.email,
        phone: users.phone
      })
      .from(playerTransactions)
      .leftJoin(users, eq(playerTransactions.agentId, users.id))
      .orderBy(desc(playerTransactions.createdAt));
      
      // Get all remittance transactions
      const remittanceTxs = await db.select({
        id: remittanceTransactions.id,
        agentId: remittanceTransactions.agentId,
        recipientChannel: remittanceTransactions.recipientChannel,
        recipientName: remittanceTransactions.recipientName,
        recipientAccount: remittanceTransactions.recipientAccount,
        recipientAdditionalInfo: remittanceTransactions.recipientAdditionalInfo,
        amount: remittanceTransactions.amount,
        feeId: remittanceTransactions.feeId,
        feeAmount: remittanceTransactions.feeAmount,
        totalAmount: remittanceTransactions.totalAmount,
        status: remittanceTransactions.status,
        statusReason: remittanceTransactions.statusReason,
        processedById: remittanceTransactions.processedById, 
        processedAt: remittanceTransactions.processedAt,
        transactionNumber: remittanceTransactions.transactionNumber,
        notes: remittanceTransactions.notes,
        createdAt: remittanceTransactions.createdAt,
        updatedAt: remittanceTransactions.updatedAt,
        // Join agent data
        username: users.username,
        fullName: users.fullName,
        email: users.email,
        phone: users.phone
      })
      .from(remittanceTransactions)
      .leftJoin(users, eq(remittanceTransactions.agentId, users.id))
      .orderBy(desc(remittanceTransactions.createdAt));
      
      // Format top-up transactions
      const formattedTopups = topupTxs.map(tx => ({
        id: `topup-${tx.id}`,
        originalId: tx.id,
        type: "USDT Top-up",
        transactionType: "topup",
        amount: Number(tx.amount),
        currency: tx.currency,
        convertedAmount: tx.convertedAmount ? Number(tx.convertedAmount) : undefined,
        conversionRate: tx.conversionRate ? Number(tx.conversionRate) : undefined,
        date: new Date(tx.createdAt).toLocaleDateString(),
        time: new Date(tx.createdAt).toLocaleTimeString(),
        timestamp: new Date(tx.createdAt).toISOString(),
        status: tx.status,
        statusReason: tx.statusReason,
        paymentMethod: tx.paymentMethod,
        walletAddress: tx.walletAddress,
        accountNumber: tx.accountNumber,
        bankDetails: tx.bankDetails,
        transactionId: tx.transactionId,
        processedById: tx.processedById,
        processedAt: tx.processedAt,
        userId: tx.userId,
        username: tx.username,
        fullName: tx.fullName,
        email: tx.email,
        phone: tx.phone,
        createdAt: tx.createdAt,
        updatedAt: tx.updatedAt
      }));
      
      // Format withdrawal transactions
      const formattedWithdrawals = withdrawalTxs.map(tx => ({
        id: `withdrawal-${tx.id}`,
        originalId: tx.id,
        type: "Withdrawal",
        transactionType: "withdrawal",
        amount: Number(tx.amount),
        currency: "BDT",
        method: tx.withdrawalMethod,
        accountNumber: tx.accountNumber,
        walletAddress: tx.walletAddress,
        bankDetails: tx.bankDetails,
        reference: tx.reference,
        date: new Date(tx.createdAt).toLocaleDateString(),
        time: new Date(tx.createdAt).toLocaleTimeString(),
        timestamp: new Date(tx.createdAt).toISOString(),
        status: tx.status,
        statusReason: tx.statusReason,
        processedById: tx.processedById,
        processedAt: tx.processedAt,
        userId: tx.userId,
        username: tx.username,
        fullName: tx.fullName,
        email: tx.email,
        phone: tx.phone,
        createdAt: tx.createdAt,
        updatedAt: tx.updatedAt
      }));
      
      // Format player transactions
      const formattedPlayerTxs = playerTxs.map(tx => ({
        id: `player-${tx.id}`,
        originalId: tx.id,
        type: tx.type === "deposit" ? "Player Deposit" : "Player Withdrawal",
        transactionType: tx.type === "deposit" ? "player_deposit" : "player_withdrawal",
        amount: Number(tx.amount),
        currency: "BDT",
        playerId: tx.playerId,
        paymentCode: tx.paymentCode,
        date: new Date(tx.createdAt).toLocaleDateString(),
        time: new Date(tx.createdAt).toLocaleTimeString(),
        timestamp: new Date(tx.createdAt).toISOString(),
        status: tx.status,
        statusReason: tx.statusReason,
        processedById: tx.processedById,
        processedAt: tx.processedAt,
        commissionAmount: tx.commissionAmount ? Number(tx.commissionAmount) : undefined,
        agentId: tx.agentId,
        username: tx.username,
        fullName: tx.fullName,
        email: tx.email,
        phone: tx.phone,
        createdAt: tx.createdAt,
        updatedAt: tx.updatedAt
      }));
      
      // Format remittance transactions
      const formattedRemittanceTxs = remittanceTxs.map(tx => ({
        id: `remittance-${tx.id}`,
        originalId: tx.id,
        type: "Remittance",
        transactionType: "remittance",
        amount: Number(tx.amount),
        feeAmount: tx.feeAmount ? Number(tx.feeAmount) : 0,
        totalAmount: tx.totalAmount ? Number(tx.totalAmount) : Number(tx.amount),
        currency: "BDT",
        recipientChannel: tx.recipientChannel,
        recipientName: tx.recipientName,
        recipientAccount: tx.recipientAccount,
        recipientAdditionalInfo: tx.recipientAdditionalInfo,
        transactionNumber: tx.transactionNumber,
        date: new Date(tx.createdAt).toLocaleDateString(),
        time: new Date(tx.createdAt).toLocaleTimeString(),
        timestamp: new Date(tx.createdAt).toISOString(),
        status: tx.status,
        statusReason: tx.statusReason,
        processedById: tx.processedById,
        processedAt: tx.processedAt,
        agentId: tx.agentId,
        username: tx.username,
        fullName: tx.fullName,
        email: tx.email,
        phone: tx.phone,
        notes: tx.notes,
        createdAt: tx.createdAt,
        updatedAt: tx.updatedAt
      }));
      
      // Combine all transaction types
      let allTransactions = [
        ...formattedTopups, 
        ...formattedWithdrawals, 
        ...formattedPlayerTxs,
        ...formattedRemittanceTxs
      ];
      
      // Apply filters if provided
      if (filters) {
        // Filter by date range
        if (filters.startDate) {
          allTransactions = allTransactions.filter(tx => 
            new Date(tx.createdAt) >= new Date(filters.startDate!)
          );
        }
        
        if (filters.endDate) {
          allTransactions = allTransactions.filter(tx => 
            new Date(tx.createdAt) <= new Date(filters.endDate!)
          );
        }
        
        // Filter by transaction type
        if (filters.type && filters.type.length > 0) {
          allTransactions = allTransactions.filter(tx => 
            filters.type!.includes(tx.transactionType)
          );
        }
        
        // Filter by status
        if (filters.status && filters.status.length > 0) {
          allTransactions = allTransactions.filter(tx => 
            filters.status!.includes(tx.status)
          );
        }
        
        // Filter by agentId
        if (filters.agentId !== undefined) {
          allTransactions = allTransactions.filter(tx => {
            if (tx.transactionType === 'topup' || tx.transactionType === 'withdrawal') {
              return tx.userId === filters.agentId;
            } else if (tx.transactionType === 'player_deposit' || tx.transactionType === 'player_withdrawal' || tx.transactionType === 'remittance') {
              return tx.agentId === filters.agentId;
            }
            return false;
          });
        }
        
        // Filter by playerId
        if (filters.playerId) {
          allTransactions = allTransactions.filter(tx => {
            if (tx.transactionType === 'player_deposit' || tx.transactionType === 'player_withdrawal') {
              return tx.playerId === filters.playerId;
            }
            return false;
          });
        }
        
        // Search functionality
        if (filters.search) {
          const searchTerm = filters.search.toLowerCase();
          allTransactions = allTransactions.filter(tx => {
            // Common searchable fields for all transaction types
            const commonFields = [
              tx.id,
              tx.type,
              tx.status,
              tx.amount?.toString(),
              tx.date,
              tx.time,
              tx.username,
              tx.fullName,
              tx.email,
              tx.phone
            ].filter(Boolean); // Remove undefined/null values
            
            // Transaction-specific fields
            let typeSpecificFields: string[] = [];
            
            if (tx.transactionType === 'topup') {
              typeSpecificFields = [
                tx.paymentMethod,
                tx.transactionId,
                tx.walletAddress,
                tx.accountNumber,
                tx.bankDetails
              ].filter(Boolean);
            } else if (tx.transactionType === 'withdrawal') {
              typeSpecificFields = [
                tx.method,
                tx.reference,
                tx.walletAddress,
                tx.accountNumber,
                tx.bankDetails
              ].filter(Boolean);
            } else if (tx.transactionType === 'player_deposit' || tx.transactionType === 'player_withdrawal') {
              typeSpecificFields = [
                tx.playerId,
                tx.paymentCode
              ].filter(Boolean);
            } else if (tx.transactionType === 'remittance') {
              typeSpecificFields = [
                tx.recipientName,
                tx.recipientAccount,
                tx.recipientChannel,
                tx.transactionNumber,
                tx.notes
              ].filter(Boolean);
            }
            
            // Combine common and type-specific fields
            const allSearchableFields = [...commonFields, ...typeSpecificFields];
            
            // Check if any field contains the search term
            return allSearchableFields.some(field => 
              field?.toLowerCase().includes(searchTerm)
            );
          });
        }
      }
      
      // Sort by date (newest first)
      return allTransactions.sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
    } catch (error) {
      console.error("Error in getAllTransactions:", error);
      throw error;
    }
  }
  
  // Helper method to check if a transaction ID exists in the topup_transactions table
  async isTopupTransaction(transactionId: number): Promise<boolean> {
    try {
      const [transaction] = await db.select()
        .from(topupTransactions)
        .where(eq(topupTransactions.id, transactionId));
      
      return !!transaction;
    } catch (error) {
      console.error("Error in isTopupTransaction:", error);
      return false;
    }
  }
  
  // Approve a pending transaction
  async approveTransaction(transactionId: number, approve: boolean, reason: string): Promise<any> {
    console.log("Processing transaction:", transactionId, approve ? "approve" : "reject", reason);
    
    // We now pass the originalId directly - no need to parse it again
    // This helps avoid NaN errors when trying to parse prefixed IDs
    const originalId = transactionId;
    
    // For logging, determine transaction type
    const isTopupTransaction = await this.isTopupTransaction(originalId);
    const isPlayerTransaction = !isTopupTransaction; // For now we only have these two types
    
    console.log(`Transaction type: ${isPlayerTransaction ? 'player' : isTopupTransaction ? 'topup' : 'unknown'}, ID: ${originalId}`);
    
    try {
      return await db.transaction(async (tx) => {
        // Get the transaction based on its type
        let transaction;
        
        if (isPlayerTransaction) {
          [transaction] = await tx.select().from(playerTransactions)
            .where(eq(playerTransactions.id, originalId));
        } else if (isTopupTransaction) {
          [transaction] = await tx.select().from(topupTransactions)
            .where(eq(topupTransactions.id, originalId));
        } else {
          // Try player transactions by default for backward compatibility
          [transaction] = await tx.select().from(playerTransactions)
            .where(eq(playerTransactions.id, transactionId));
        }
          
        if (!transaction) {
          throw new Error("Transaction not found");
        }
        
        // Handle case where transaction is already processed
        if (transaction.status !== "pending") {
          console.log(`Transaction ${transactionId} is already ${transaction.status}, returning existing transaction`);
          return transaction; // Just return the transaction instead of throwing an error
        }
        
        // Handle different transaction types
        if (isTopupTransaction || 'userId' in transaction) {
          // This is a topup transaction
          return await this.approveTopupTransaction(tx, originalId, approve, reason);
        } else {
          // This is a player transaction - Use the existing code for now
          const [transaction] = await tx.select().from(playerTransactions)
            .where(eq(playerTransactions.id, originalId));
            
          if (!transaction) {
            throw new Error("Player transaction not found");
          }
          
          // Get the agent
          const [agent] = await tx.select().from(users)
            .where(eq(users.id, transaction.agentId));
            
          if (!agent) {
            throw new Error("Agent not found");
          }
          
          // Update transaction status
          await tx.update(playerTransactions)
            .set({ 
              status: approve ? "approved" : "rejected",
              statusReason: reason || (approve ? "Approved by admin" : "Rejected by admin"),
              updatedAt: new Date()
            })
            .where(eq(playerTransactions.id, originalId));
          
          // Process the transaction based on type
          if (approve) {
            if (transaction.type === "deposit") {
              // For deposits, deduct from agent's balance
              if (Number(agent.balance) < Number(transaction.amount)) {
                // If agent doesn't have sufficient balance, reject the transaction
                await tx.update(playerTransactions)
                  .set({ 
                    status: "rejected",
                    statusReason: "Insufficient agent balance",
                    updatedAt: new Date()
                  })
                  .where(eq(playerTransactions.id, originalId));
                  
                return {
                  ...transaction,
                  status: "rejected",
                  statusReason: "Insufficient agent balance"
                };
              }
              
              // Update agent balance - Handle NaN values properly
              let agentBalance = 0;
              try {
                agentBalance = parseFloat(agent.balance?.toString() || '0');
                if (isNaN(agentBalance)) agentBalance = 0;
              } catch (e) {
                console.warn("Invalid agent balance:", agent.balance);
              }
              
              let transactionAmount = 0;
              try {
                transactionAmount = parseFloat(transaction.amount?.toString() || '0');
                if (isNaN(transactionAmount)) transactionAmount = 0;
              } catch (e) {
                console.warn("Invalid transaction amount:", transaction.amount);
              }
              
              const newBalance = agentBalance - transactionAmount;
              console.log(`Updating agent ${agent.id} balance: ${agentBalance} - ${transactionAmount} = ${newBalance}`);
              
              await tx.update(users)
                .set({ balance: newBalance.toString() })
                .where(eq(users.id, transaction.agentId));
                
              // Process commission
              const commissionAmount = Number(transaction.commissionAmount || 0);
              if (commissionAmount > 0) {
                // Create commission entry
                await tx.insert(commissions).values({
                  agentId: transaction.agentId,
                  playerId: transaction.playerId,
                  transactionId: transaction.id,
                  type: "deposit",
                  amount: transaction.amount,
                  commission: transaction.commissionAmount || "0",
                  isPaid: false,
                  paidDate: null,
                  scheduledPayout: new Date()
                });
              }
            } else if (transaction.type === "withdrawal") {
              // For withdrawals, add to agent's balance - Handle NaN values properly
              let agentBalance = 0;
              try {
                agentBalance = parseFloat(agent.balance?.toString() || '0');
                if (isNaN(agentBalance)) agentBalance = 0;
              } catch (e) {
                console.warn("Invalid agent balance:", agent.balance);
              }
              
              let transactionAmount = 0;
              try {
                transactionAmount = parseFloat(transaction.amount?.toString() || '0');
                if (isNaN(transactionAmount)) transactionAmount = 0;
              } catch (e) {
                console.warn("Invalid transaction amount:", transaction.amount);
              }
              
              const newBalance = agentBalance + transactionAmount;
              console.log(`Updating agent ${agent.id} balance: ${agentBalance} + ${transactionAmount} = ${newBalance}`);
              
              await tx.update(users)
                .set({ balance: newBalance.toString() })
                .where(eq(users.id, transaction.agentId));
                
              // Process commission
              const commissionAmount = Number(transaction.commissionAmount || 0);
              if (commissionAmount > 0) {
                // Create commission entry
                await tx.insert(commissions).values({
                  agentId: transaction.agentId,
                  playerId: transaction.playerId,
                  transactionId: transaction.id,
                  type: "withdrawal",
                  amount: transaction.amount,
                  commission: transaction.commissionAmount || "0",
                  isPaid: false,
                  paidDate: null,
                  scheduledPayout: new Date()
                });
              }
            }
          }
          
          // Send notification
          const { sendNotification } = await import('./scheduled-jobs');
          sendNotification(transaction.agentId, {
            type: 'transaction',
            action: approve ? 'approved' : 'rejected',
            data: {
              transactionId: transaction.id,
              transactionType: transaction.type,
              amount: Number(transaction.amount),
              status: approve ? 'approved' : 'rejected',
              reason: reason || (approve ? "Approved by admin" : "Rejected by admin"),
              timestamp: new Date().toISOString()
            },
            message: `Your ${transaction.type} transaction of ৳${Number(transaction.amount).toLocaleString()} has been ${approve ? 'approved' : 'rejected'}.`
          });
          
          return {
            ...transaction,
            status: approve ? "approved" : "rejected",
            statusReason: reason || (approve ? "Approved by admin" : "Rejected by admin"),
          };
        }
        
        // Get the agent
        const [agent] = await tx.select().from(users)
          .where(eq(users.id, transaction.agentId));
          
        if (!agent) {
          throw new Error("Agent not found");
        }
        
        if (approve) {
          // Try to find the player (may or may not exist)
          let player = null;
          
          try {
            // Try to convert player ID to number and find existing player
            const playerId = parseInt(transaction.playerId);
            if (!isNaN(playerId)) {
              const [existingPlayer] = await tx.select().from(players)
                .where(eq(players.id, playerId));
              
              if (existingPlayer) {
                player = existingPlayer;
              }
            }
          } catch (e) {
            // Ignore errors if player not found or ID isn't numeric
            console.log("Player lookup failed:", e);
          }
          
          if (transaction.type === "deposit") {
            // For deposits, deduct from agent's balance
            if (Number(agent.balance) < Number(transaction.amount)) {
              // If agent doesn't have sufficient balance, reject the transaction
              await tx.update(playerTransactions)
                .set({ 
                  status: "rejected",
                  statusReason: "Insufficient agent balance",
                  updatedAt: new Date()
                })
                .where(eq(playerTransactions.id, transactionId));
                
              return {
                ...transaction,
                status: "rejected",
                statusReason: "Insufficient agent balance"
              };
            }
            
            // Update agent balance
            const newBalance = Number(agent.balance) - Number(transaction.amount);
            await tx.update(users)
              .set({ balance: newBalance.toString() })
              .where(eq(users.id, transaction.agentId));
              
            // Check if today is the 4th of the month (for deposits too, same as withdrawals)
            const today = new Date();
            const isPaidImmediately = today.getDate() === 4;
            
            // Calculate commission payout date (4th of next month if today is not the 4th)
            let payoutDate: Date | null = null;
            const commissionAmount = Number(transaction.commissionAmount || 0);
            
            if (!isPaidImmediately && commissionAmount > 0) {
              payoutDate = new Date();
              // Set to the 4th of the current month
              payoutDate.setDate(4);
              // If we're already past the 4th, move to next month
              if (today.getDate() > 4) {
                payoutDate.setMonth(payoutDate.getMonth() + 1);
              }
            }
            
            // Create commission entry
            const [commission] = await tx.insert(commissions).values({
              agentId: transaction.agentId,
              playerId: transaction.playerId,
              transactionId: transaction.id,
              type: "deposit",
              amount: transaction.amount,
              commission: transaction.commissionAmount || "0",
              isPaid: isPaidImmediately,
              paidDate: isPaidImmediately ? new Date() : null,
              scheduledPayout: payoutDate
            }).returning();
            
            // If it's the 4th of the month, add commission to the agent's balance now
            if (isPaidImmediately && commissionAmount > 0) {
              // We deducted the transaction amount above, but now we need to add the commission
              const balanceWithCommission = newBalance + commissionAmount;
              await tx.update(users)
                .set({ balance: balanceWithCommission.toString() })
                .where(eq(users.id, transaction.agentId));
                
              console.log(`Deposit commission of ${commissionAmount} added to agent ${agent.id}'s balance immediately`);
              
              // Send immediate notification about commission payment
              // First get the player info for better notification details
              let playerUsername = 'Unknown Player';
              if (player) {
                playerUsername = player.username;
              } else {
                try {
                  const [playerInfo] = await tx.select().from(players)
                    .where(eq(players.id, parseInt(transaction.playerId)));
                  if (playerInfo) {
                    playerUsername = playerInfo.username;
                  }
                } catch (e) {
                  console.log("Could not find player info for notification:", e);
                }
              }
              
              // Send WebSocket notification to agent
              const { sendNotification } = await import('./scheduled-jobs');
              sendNotification(transaction.agentId, {
                type: 'commission',
                action: 'paid',
                data: {
                  commissionId: commission.id,
                  amount: commissionAmount,
                  commissionType: "deposit",
                  playerId: transaction.playerId,
                  playerUsername: playerUsername,
                  timestamp: new Date().toISOString()
                },
                message: `Your deposit commission of ৳${commissionAmount.toLocaleString()} has been paid and added to your balance.`
              });
              
              // Notify admins
              const adminUsers = await tx.select().from(users).where(eq(users.role, 'admin'));
              for (const admin of adminUsers) {
                sendNotification(admin.id, {
                  type: 'admin_notification',
                  action: 'commission_paid',
                  data: {
                    agentId: transaction.agentId,
                    agentUsername: agent.username,
                    commissionId: commission.id,
                    amount: commissionAmount,
                    commissionType: "deposit",
                    timestamp: new Date().toISOString()
                  },
                  message: `Deposit commission of ৳${commissionAmount.toLocaleString()} paid to agent ${agent.username}.`
                });
              }
            } else if (commissionAmount > 0) {
              console.log(`Deposit commission of ${commissionAmount} for agent ${agent.id} scheduled for payout on ${payoutDate?.toISOString()}`);
              
              // Send notification about scheduled commission
              const { sendNotification } = await import('./scheduled-jobs');
              sendNotification(transaction.agentId, {
                type: 'commission',
                action: 'scheduled',
                data: {
                  commissionId: commission.id,
                  amount: commissionAmount,
                  commissionType: "deposit",
                  playerId: transaction.playerId,
                  scheduledDate: payoutDate?.toISOString(),
                  timestamp: new Date().toISOString()
                },
                message: `Your deposit commission of ৳${commissionAmount.toLocaleString()} has been scheduled for payout on ${payoutDate?.toLocaleDateString()}.`
              });
            }
            
            // If player exists, update their data
            if (player) {
              const totalDeposits = Number(player.totalDeposits || 0) + Number(transaction.amount);
              await tx.update(players).set({
                totalDeposits: totalDeposits.toString(),
                // If this is the first deposit, set the firstDepositAmount
                ...(Number(player.firstDepositAmount || 0) === 0 ? 
                  { firstDepositAmount: transaction.amount } : {})
              }).where(eq(players.id, player.id));
            }
          } else if (transaction.type === "withdrawal") {
            // For withdrawals, add the withdrawal amount to agent's balance immediately
            // Handle NaN values properly
            let withdrawalAmount = 0;
            try {
              withdrawalAmount = parseFloat(transaction.amount?.toString() || '0');
              if (isNaN(withdrawalAmount)) withdrawalAmount = 0;
            } catch (e) {
              console.warn("Invalid withdrawal amount:", transaction.amount);
            }
            
            let commissionAmount = 0;
            try {
              commissionAmount = parseFloat(transaction.commissionAmount?.toString() || '0');
              if (isNaN(commissionAmount)) commissionAmount = 0;
            } catch (e) {
              console.warn("Invalid commission amount:", transaction.commissionAmount);
            }
            
            // Add main transaction amount to agent's balance
            let agentBalance = 0;
            try {
              agentBalance = parseFloat(agent.balance?.toString() || '0');
              if (isNaN(agentBalance)) agentBalance = 0;
            } catch (e) {
              console.warn("Invalid agent balance:", agent.balance);
            }
            
            const newBalance = agentBalance + withdrawalAmount;
            console.log(`Updating agent ${agent.id} balance for withdrawal: ${agentBalance} + ${withdrawalAmount} = ${newBalance}`);
            
            await tx.update(users)
              .set({ balance: newBalance.toString() })
              .where(eq(users.id, transaction.agentId));
              
            // Check if today is the 4th of the month
            const today = new Date();
            const isPaidImmediately = today.getDate() === 4;
            
            // Calculate commission payout date (4th of next month if today is not the 4th)
            let payoutDate: Date | null = null;
            
            if (!isPaidImmediately && commissionAmount > 0) {
              payoutDate = new Date();
              // Set to the 4th of the current month
              payoutDate.setDate(4);
              // If we're already past the 4th, move to next month
              if (today.getDate() > 4) {
                payoutDate.setMonth(payoutDate.getMonth() + 1);
              }
            }
            
            // Create commission entry
            const [commission] = await tx.insert(commissions).values({
              agentId: transaction.agentId,
              playerId: transaction.playerId,
              transactionId: transaction.id,
              type: "withdrawal",
              amount: transaction.amount,
              commission: transaction.commissionAmount || "0",
              isPaid: isPaidImmediately,
              paidDate: isPaidImmediately ? new Date() : null,
              scheduledPayout: payoutDate
            }).returning();
            
            // If it's the 4th of the month, add commission to the agent's balance now
            if (isPaidImmediately && commissionAmount > 0) {
              const balanceWithCommission = newBalance + commissionAmount;
              await tx.update(users)
                .set({ balance: balanceWithCommission.toString() })
                .where(eq(users.id, transaction.agentId));
                
              console.log(`Withdrawal commission of ${commissionAmount} added to agent ${agent.id}'s balance immediately`);
              
              // Send immediate notification about commission payment
              // First get the player info for better notification details
              let playerUsername = 'Unknown Player';
              if (player) {
                playerUsername = player.username;
              } else {
                try {
                  const [playerInfo] = await tx.select().from(players)
                    .where(eq(players.id, parseInt(transaction.playerId)));
                  if (playerInfo) {
                    playerUsername = playerInfo.username;
                  }
                } catch (e) {
                  console.log("Could not find player info for notification:", e);
                }
              }
              
              // Send WebSocket notification to agent
              const { sendNotification } = await import('./scheduled-jobs');
              sendNotification(transaction.agentId, {
                type: 'commission',
                action: 'paid',
                data: {
                  commissionId: commission.id,
                  amount: commissionAmount,
                  commissionType: "withdrawal",
                  playerId: transaction.playerId,
                  playerUsername: playerUsername,
                  timestamp: new Date().toISOString()
                },
                message: `Your withdrawal commission of ৳${commissionAmount.toLocaleString()} has been paid and added to your balance.`
              });
              
              // Notify admins
              const adminUsers = await tx.select().from(users).where(eq(users.role, 'admin'));
              for (const admin of adminUsers) {
                sendNotification(admin.id, {
                  type: 'admin_notification',
                  action: 'commission_paid',
                  data: {
                    agentId: transaction.agentId,
                    agentUsername: agent.username,
                    commissionId: commission.id,
                    amount: commissionAmount,
                    commissionType: "withdrawal",
                    timestamp: new Date().toISOString()
                  },
                  message: `Withdrawal commission of ৳${commissionAmount.toLocaleString()} paid to agent ${agent.username}.`
                });
              }
            } else if (commissionAmount > 0) {
              console.log(`Withdrawal commission of ${commissionAmount} for agent ${agent.id} scheduled for payout on ${payoutDate?.toISOString()}`);
              
              // Send notification about scheduled commission
              const { sendNotification } = await import('./scheduled-jobs');
              sendNotification(transaction.agentId, {
                type: 'commission',
                action: 'scheduled',
                data: {
                  commissionId: commission.id,
                  amount: commissionAmount,
                  commissionType: "withdrawal",
                  playerId: transaction.playerId,
                  scheduledDate: payoutDate?.toISOString(),
                  timestamp: new Date().toISOString()
                },
                message: `Your withdrawal commission of ৳${commissionAmount.toLocaleString()} has been scheduled for payout on ${payoutDate?.toLocaleDateString()}.`
              });
            }
            
            // If player exists, update their data
            if (player) {
              const totalWithdrawals = Number(player.totalWithdrawals || 0) + withdrawalAmount;
              await tx.update(players).set({
                totalWithdrawals: totalWithdrawals.toString()
              }).where(eq(players.id, player.id));
            }
          }
          
          // Update transaction status to approved
          await tx.update(playerTransactions)
            .set({ 
              status: "approved",
              statusReason: reason || "Approved by admin",
              updatedAt: new Date()
            })
            .where(eq(playerTransactions.id, transactionId));
            
          return {
            ...transaction,
            status: "approved",
            statusReason: reason || "Approved by admin"
          };
        } else {
          // Reject the transaction
          await tx.update(playerTransactions)
            .set({ 
              status: "rejected",
              statusReason: reason || "Rejected by admin",
              updatedAt: new Date()
            })
            .where(eq(playerTransactions.id, transactionId));
            
          return {
            ...transaction,
            status: "rejected",
            statusReason: reason || "Rejected by admin"
          };
        }
      });
    } catch (error) {
      console.error("Error processing transaction:", error);
      throw error;
    }
  }

  async getTopupTransactionsByUserId(userId: number): Promise<any[]> {
    const txs = await db.select().from(topupTransactions)
      .where(eq(topupTransactions.userId, userId))
      .orderBy(desc(topupTransactions.createdAt));
    
    return txs.map(tx => ({
      id: tx.transactionId,
      type: "USDT Top-up",
      amount: Number(tx.amount),
      currency: tx.currency,
      convertedAmount: Number(tx.convertedAmount),
      walletAddress: tx.walletAddress,
      paymentMethod: tx.paymentMethod,
      date: new Date(tx.createdAt).toLocaleDateString(),
      time: new Date(tx.createdAt).toLocaleTimeString(),
      status: tx.status,
    }));
  }

  // Players
  async getPlayersByAgentId(agentId: number): Promise<any[]> {
    try {
      const result = await db.select().from(players)
        .where(eq(players.agentId, agentId))
        .orderBy(desc(players.registrationDate));
      
      return result.map(player => ({
        id: player.id,
        username: player.username,
        registrationDate: new Date(player.registrationDate).toLocaleDateString(),
        totalDeposits: Number(player.totalDeposits),
        totalWithdrawals: Number(player.totalWithdrawals),
        isActive: player.isActive
      }));
    } catch (error) {
      console.error("Error in getPlayersByAgentId:", error);
      throw error;
    }
  }

  // Player deposit requests
  async createPlayerDepositRequest(agentId: number, data: any): Promise<any> {
    console.log("DatabaseStorage: Processing deposit request", { agentId, data });
    try {
      const result = await db.transaction(async (tx) => {
        // Check if user exists
        const [user] = await tx.select().from(users).where(eq(users.id, agentId));
        if (!user) {
          throw new Error("Agent not found");
        }

        // Check balance
        if (Number(user.balance) < data.amount) {
          throw new Error("Insufficient balance");
        }
        
        const playerId = data.playerId.toString();
        
        // Create transaction with "pending" status (default)
        const [transaction] = await tx.insert(playerTransactions).values({
          agentId,
          playerId,
          type: "deposit",
          amount: data.amount.toString(),
          status: "pending", // All transactions start as pending
          commissionAmount: (data.amount * 0.02).toString() // 2% commission on deposits
        }).returning();

        console.log("Pending transaction created:", transaction);
        
        // Return the formatted transaction data
        return {
          id: transaction.id,
          agentId: transaction.agentId,
          playerId: transaction.playerId,
          type: transaction.type,
          amount: Number(transaction.amount),
          status: transaction.status,
          commissionAmount: Number(transaction.commissionAmount || 0),
          date: new Date(transaction.createdAt).toLocaleDateString(),
          time: new Date(transaction.createdAt).toLocaleTimeString()
        };
      });
      
      return result;
    } catch (error) {
      console.error("Error in createPlayerDepositRequest:", error);
      throw error;
    }
  }

  // Player withdrawal requests
  async createPlayerWithdrawalRequest(agentId: number, data: any): Promise<any> {
    console.log("DatabaseStorage: Processing withdrawal request", { agentId, data });
    try {
      const result = await db.transaction(async (tx) => {
        // Check if user exists
        const [user] = await tx.select().from(users).where(eq(users.id, agentId));
        if (!user) {
          throw new Error("Agent not found");
        }

        const playerId = data.playerId.toString();
        
        // Calculate commission (1% on withdrawals)
        const commissionAmount = data.amount * 0.01;

        // Create transaction with "pending" status
        const [transaction] = await tx.insert(playerTransactions).values({
          agentId,
          playerId,
          type: "withdrawal",
          amount: data.amount.toString(),
          paymentCode: data.paymentCode,
          status: "pending", // All transactions start as pending
          commissionAmount: commissionAmount.toString()
        }).returning();

        console.log("Pending transaction created:", transaction);
        
        // Return the formatted transaction data
        return {
          id: transaction.id,
          agentId: transaction.agentId,
          playerId: transaction.playerId,
          type: transaction.type,
          amount: Number(transaction.amount),
          paymentCode: transaction.paymentCode,
          status: transaction.status,
          commissionAmount: Number(transaction.commissionAmount || 0),
          date: new Date(transaction.createdAt).toLocaleDateString(),
          time: new Date(transaction.createdAt).toLocaleTimeString()
        };
      });
      
      return result;
    } catch (error) {
      console.error("Error in createPlayerWithdrawalRequest:", error);
      throw error;
    }
  }

  // Commissions
  async getCommissionsByUserId(userId: number): Promise<any[]> {
    try {
      const result = await db.select().from(commissions)
        .where(eq(commissions.agentId, userId))
        .orderBy(desc(commissions.createdAt));
      
      // Get players info for each commission
      const commissionWithPlayerNames = await Promise.all(
        result.map(async (commission) => {
          const [player] = await db.select().from(players)
            .where(eq(players.id, commission.playerId));
          
          return {
            id: commission.id,
            type: commission.type,
            playerId: commission.playerId,
            playerUsername: player ? player.username : `Player-${commission.playerId}`,
            amount: Number(commission.amount),
            commission: Number(commission.commission),
            date: new Date(commission.createdAt).toLocaleDateString(),
            isPaid: commission.isPaid,
            paidDate: commission.paidDate ? new Date(commission.paidDate).toLocaleDateString() : undefined,
            scheduledPayout: commission.scheduledPayout ? new Date(commission.scheduledPayout).toLocaleDateString() : undefined,
          };
        })
      );
      
      return commissionWithPlayerNames;
    } catch (error) {
      console.error("Error in getCommissionsByUserId:", error);
      throw error;
    }
  }

  async getCommissionsSummary(userId: number): Promise<any> {
    const commissions = await this.getCommissionsByUserId(userId);
    
    const pendingAmount = commissions
      .filter(c => !c.isPaid)
      .reduce((sum, c) => sum + c.commission, 0);
    
    const totalEarnings = commissions
      .reduce((sum, c) => sum + c.commission, 0);
    
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const currentMonthEarnings = commissions
      .filter(c => {
        const date = new Date(c.date);
        return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
      })
      .reduce((sum, c) => sum + c.commission, 0);
      
    // Generate monthly data for the past 6 months
    const monthlyData = [];
    for (let i = 0; i < 6; i++) {
      const month = new Date();
      month.setMonth(month.getMonth() - i);
      const monthName = month.toLocaleString('default', { month: 'short' });
      const year = month.getFullYear();
      const monthStart = new Date(year, month.getMonth(), 1);
      const monthEnd = new Date(year, month.getMonth() + 1, 0);
      
      const depositCommissions = commissions
        .filter(c => {
          const date = new Date(c.date);
          return date >= monthStart && date <= monthEnd && c.type === 'deposit';
        })
        .reduce((sum, c) => sum + c.commission, 0);
      
      const withdrawalCommissions = commissions
        .filter(c => {
          const date = new Date(c.date);
          return date >= monthStart && date <= monthEnd && c.type === 'withdrawal';
        })
        .reduce((sum, c) => sum + c.commission, 0);
      
      monthlyData.push({
        month: `${monthName} ${year}`,
        deposit: depositCommissions,
        withdrawal: withdrawalCommissions,
      });
    }
    
    // Find the next payout date from scheduled commissions
    let payoutDateForDisplay; 
    const pendingCommissions = commissions.filter(c => !c.isPaid);
    
    if (pendingCommissions.length > 0) {
      // Get all scheduled payout dates
      const scheduledPayouts = pendingCommissions
        .filter(c => c.scheduledPayout)
        .map(c => new Date(c.scheduledPayout));
      
      // If no scheduled payouts and pending commissions, set next payout to 4th of next month
      if (scheduledPayouts.length === 0) {
        payoutDateForDisplay = new Date();
        payoutDateForDisplay.setDate(4);
        // If today is already past the 4th, move to next month
        if (payoutDateForDisplay.getDate() < 4) {
          payoutDateForDisplay.setMonth(payoutDateForDisplay.getMonth() + 1);
        }
      } else {
        // Find the earliest date
        payoutDateForDisplay = new Date(Math.min(...scheduledPayouts.map(date => date.getTime())));
      }
    } else {
      // Default date if no pending commissions
      payoutDateForDisplay = new Date();
      payoutDateForDisplay.setDate(4);
      // If today is already past the 4th, move to next month
      if (payoutDateForDisplay.getDate() < 4) {
        payoutDateForDisplay.setMonth(payoutDateForDisplay.getMonth() + 1);
      }
    }
    
    return {
      pendingAmount,
      nextPayoutDate: payoutDateForDisplay.toLocaleDateString(),
      currentMonthEarnings,
      totalEarnings,
      depositCommissionRate: 2,
      withdrawalCommissionRate: 1,
      monthlyData: monthlyData.reverse(),
    };
  }

  // Affiliate data
  async getAffiliateData(userId: number): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const playerCount = await db.select({ count: count() }).from(players)
      .where(eq(players.agentId, userId));
    
    return {
      promoCode: user.promoCode,
      playerCount: playerCount[0]?.count || 0,
    };
  }

  async getAffiliateStats(userId: number): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const players = await this.getReferredPlayers(userId);
    
    const firstDepositTotal = players.reduce((sum, p) => sum + p.firstDepositAmount, 0);
    
    const commissions = await this.getCommissionsByUserId(userId);
    const totalEarnings = commissions.reduce((sum, c) => sum + c.commission, 0);
    
    // Calculate last month earnings
    const lastMonth = new Date();
    lastMonth.setMonth(lastMonth.getMonth() - 1);
    const lastMonthStart = new Date(lastMonth.getFullYear(), lastMonth.getMonth(), 1);
    const lastMonthEnd = new Date(lastMonth.getFullYear(), lastMonth.getMonth() + 1, 0);
    
    const lastMonthEarnings = commissions
      .filter(c => {
        const date = new Date(c.date);
        return date >= lastMonthStart && date <= lastMonthEnd;
      })
      .reduce((sum, c) => sum + c.commission, 0);
    
    return {
      promoCode: user.promoCode,
      referralLink: `https://betwinner.com/ref?code=${user.promoCode}`,
      playerCount: players.length,
      firstDepositTotal,
      lastMonthEarnings,
      totalEarnings,
    };
  }

  async getReferredPlayers(userId: number): Promise<any[]> {
    try {
      const result = await db.select().from(players)
        .where(eq(players.agentId, userId))
        .orderBy(desc(players.registrationDate));
      
      return result.map(player => ({
        id: player.id,
        username: player.username,
        registrationDate: new Date(player.registrationDate).toLocaleDateString(),
        firstDepositAmount: Number(player.firstDepositAmount || 0),
        totalDeposits: Number(player.totalDeposits),
        totalCommission: Number(player.totalDeposits) * 0.02 + Number(player.totalWithdrawals) * 0.01,
        isActive: player.isActive,
      }));
    } catch (error) {
      console.error("Error in getReferredPlayers:", error);
      throw error;
    }
  }

  // Support tickets
  async getSupportTicketsByUserId(userId: number): Promise<any[]> {
    const tickets = await db.select().from(supportTickets)
      .where(eq(supportTickets.userId, userId))
      .orderBy(desc(supportTickets.lastActivity));
    
    const ticketPromises = tickets.map(async ticket => {
      const messages = await db.select().from(supportMessages)
        .where(eq(supportMessages.ticketId, ticket.id))
        .orderBy(supportMessages.createdAt);
      
      const formattedMessages = messages.map(msg => ({
        id: msg.id,
        content: msg.content,
        sender: msg.sender,
        timestamp: msg.createdAt,
        read: msg.read,
      }));
      
      const unreadCount = formattedMessages.filter(msg => !msg.read && msg.sender === 'admin').length;
      
      return {
        id: ticket.id,
        subject: ticket.subject,
        status: ticket.status,
        lastActivity: new Date(ticket.lastActivity).toLocaleDateString(),
        unreadCount,
        messages: formattedMessages,
      };
    });
    
    return Promise.all(ticketPromises);
  }

  async createSupportTicket(userId: number, data: any): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const now = new Date();
    
    // Create ticket
    const [ticket] = await db.insert(supportTickets).values({
      userId,
      subject: data.subject,
      status: "open",
      lastActivity: now
    }).returning();
    
    // Add initial message
    const [message] = await db.insert(supportMessages).values({
      ticketId: ticket.id,
      sender: "user",
      content: data.message,
      read: true
    }).returning();
    
    // Return the ticket with messages
    return {
      ...ticket,
      messages: [{
        id: message.id,
        content: message.content,
        sender: message.sender,
        timestamp: message.createdAt,
        read: message.read,
      }],
      unreadCount: 0,
    };
  }

  async addSupportTicketMessage(userId: number, data: any): Promise<any> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const ticketId = parseInt(data.ticketId);
    if (isNaN(ticketId)) {
      throw new Error("Invalid ticket ID");
    }
    
    const [ticket] = await db.select().from(supportTickets)
      .where(eq(supportTickets.id, ticketId));
    
    if (!ticket) {
      throw new Error("Ticket not found");
    }
    
    if (ticket.userId !== userId) {
      throw new Error("Not authorized to access this ticket");
    }
    
    const now = new Date();
    
    // Update ticket
    await db.update(supportTickets)
      .set({ 
        lastActivity: now,
        status: ticket.status === "closed" ? "open" : ticket.status
      })
      .where(eq(supportTickets.id, ticketId));
    
    // Add message
    const [message] = await db.insert(supportMessages).values({
      ticketId: ticketId,
      sender: "user",
      content: data.message,
      read: true
    }).returning();
    
    // Simulate admin response after a delay (for demo purposes)
    setTimeout(async () => {
      await db.insert(supportMessages).values({
        ticketId: ticketId,
        sender: "admin",
        content: "Thank you for your message. Our team will get back to you shortly.",
        read: false
      });
      
      // Update ticket last activity
      await db.update(supportTickets)
        .set({ lastActivity: new Date() })
        .where(eq(supportTickets.id, ticketId));
    }, 10000);
    
    return {
      id: message.id,
      content: message.content,
      sender: message.sender,
      timestamp: message.createdAt,
      read: message.read,
    };
  }

  async markSupportTicketAsRead(userId: number, ticketId: string): Promise<void> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const ticketIdNum = parseInt(ticketId);
    if (isNaN(ticketIdNum)) {
      throw new Error("Invalid ticket ID");
    }
    
    const [ticket] = await db.select().from(supportTickets)
      .where(eq(supportTickets.id, ticketIdNum));
    
    if (!ticket) {
      throw new Error("Ticket not found");
    }
    
    if (ticket.userId !== userId) {
      throw new Error("Not authorized to access this ticket");
    }
    
    // Mark all admin messages as read
    await db.update(supportMessages)
      .set({ read: true })
      .where(
        and(
          eq(supportMessages.ticketId, ticketIdNum),
          eq(supportMessages.sender, "admin"),
          eq(supportMessages.read, false)
        )
      );
  }
  
  // Approve topup transaction (for agent funds)
  private async approveTopupTransaction(tx: any, transactionId: number, approve: boolean, reason: string): Promise<any> {
    console.log("Processing topup transaction:", transactionId, approve ? "approve" : "reject", reason);
    
    // Get the transaction
    const [transaction] = await tx.select().from(topupTransactions)
      .where(eq(topupTransactions.id, transactionId));
      
    if (!transaction) {
      throw new Error("Topup transaction not found");
    }
    
    // Get the user (agent)
    const [user] = await tx.select().from(users)
      .where(eq(users.id, transaction.userId));
      
    if (!user) {
      throw new Error("User not found");
    }
    
    // Update transaction status
    await tx.update(topupTransactions)
      .set({ 
        status: approve ? "approved" : "rejected",
        statusReason: reason || (approve ? "Approved by admin" : "Rejected by admin"),
        updatedAt: new Date()
      })
      .where(eq(topupTransactions.id, transactionId));
    
    // If approved, update user balance
    if (approve) {
      // Ensure we're working with valid numbers
      let amount = 0;
      try {
        amount = parseFloat(transaction.amount.toString());
        if (isNaN(amount)) amount = 0;
      } catch (e) {
        console.warn("Invalid amount in transaction:", transaction.amount);
      }
      
      let convertedAmount = amount;
      try {
        if (transaction.convertedAmount) {
          convertedAmount = parseFloat(transaction.convertedAmount.toString());
          if (isNaN(convertedAmount)) convertedAmount = amount;
        }
      } catch (e) {
        console.warn("Invalid convertedAmount in transaction:", transaction.convertedAmount);
      }
      
      let currentBalance = 0;
      try {
        currentBalance = parseFloat(user.balance?.toString() || '0');
        if (isNaN(currentBalance)) currentBalance = 0;
      } catch (e) {
        console.warn("Invalid user balance:", user.balance);
      }
      
      const newBalance = currentBalance + convertedAmount;
      console.log(`Updating user ${user.id} balance: ${currentBalance} + ${convertedAmount} = ${newBalance}`);
      
      await tx.update(users)
        .set({ balance: newBalance.toString() })
        .where(eq(users.id, transaction.userId));
    }
    
    // Send notification to the user
    const { sendNotification } = await import('./scheduled-jobs');
    sendNotification(transaction.userId, {
      type: 'transaction',
      action: approve ? 'approved' : 'rejected',
      data: {
        transactionId: transaction.id,
        transactionType: 'topup',
        amount: Number(transaction.amount),
        currency: transaction.currency,
        convertedAmount: transaction.convertedAmount ? Number(transaction.convertedAmount) : null,
        status: approve ? 'approved' : 'rejected',
        reason: reason || (approve ? "Approved by admin" : "Rejected by admin"),
        timestamp: new Date().toISOString()
      },
      message: `Your topup of ${transaction.currency} ${Number(transaction.amount).toLocaleString()} has been ${approve ? 'approved' : 'rejected'}.${approve ? ` Your balance has been updated.` : ''}`
    });
    
    // Send notification to all admin users
    const adminUsers = await tx.select().from(users).where(eq(users.role, 'admin'));
    for (const admin of adminUsers) {
      if (admin.id !== transaction.userId) {  // Don't send to self if admin is making a topup
        sendNotification(admin.id, {
          type: 'admin_notification',
          action: 'transaction_' + (approve ? 'approved' : 'rejected'),
          data: {
            userId: transaction.userId,
            username: user.username,
            transactionId: transaction.id,
            transactionType: 'topup',
            amount: Number(transaction.amount),
            currency: transaction.currency,
            status: approve ? 'approved' : 'rejected',
            timestamp: new Date().toISOString()
          },
          message: `Admin ${approve ? 'approved' : 'rejected'} ${user.username}'s topup of ${transaction.currency} ${Number(transaction.amount).toLocaleString()}.`
        });
      }
    }
    
    return {
      ...transaction,
      status: approve ? "approved" : "rejected",
      statusReason: reason || (approve ? "Approved by admin" : "Rejected by admin"),
    };
  }
}