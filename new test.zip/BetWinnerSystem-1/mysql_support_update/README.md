# MySQL Support Update

This update adds MySQL database support to the application, enabling deployment on shared hosting environments that don't support PostgreSQL.

## Modified Files

### 1. server/db.ts
Updated to support both MySQL and PostgreSQL database connections based on the DB_TYPE environment variable.

### 2. server/database-storage.ts
Modified to handle different session store implementations based on the database type.

## Usage

1. Set the environment variable `DB_TYPE` to either `postgres` (default) or `mysql`
2. For MySQL, provide the appropriate connection string in `DATABASE_URL`

## Connection String Format

### PostgreSQL
```
DATABASE_URL=postgresql://username:password@hostname:port/database
```

### MySQL
```
DATABASE_URL=mysql://username:password@hostname:port/database
```

## Implementation Details

- The system automatically detects the database type
- For PostgreSQL, session data is stored in the database
- For MySQL, a memory store is used for session data
- All database operations use Drizzle ORM which supports both database types
