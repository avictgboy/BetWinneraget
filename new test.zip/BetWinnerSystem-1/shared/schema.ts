import { pgTable, text, serial, integer, numeric, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  email: text("email"),
  phone: text("phone"),
  balance: numeric("balance", { precision: 10, scale: 2 }).default("0").notNull(),
  agentId: text("agent_id").notNull(),
  promoCode: text("promo_code").notNull(),
  role: text("role").default("agent").notNull(), // 'admin' or 'agent'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Top-up transactions
export const topupTransactions = pgTable("topup_transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  convertedAmount: numeric("converted_amount", { precision: 10, scale: 2 }),
  conversionRate: numeric("conversion_rate", { precision: 10, scale: 2 }),
  paymentMethod: text("payment_method").notNull(),
  walletAddress: text("wallet_address"),
  accountNumber: text("account_number"), // For mobile banking methods
  bankDetails: text("bank_details"), // For bank transfers
  transactionId: text("transaction_id"), // For reference numbers
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Withdrawal transactions
export const withdrawalTransactions = pgTable("withdrawal_transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  withdrawalMethod: text("withdrawal_method").notNull(), // bank_transfer, bkash, nagad, rocket, usdt
  accountNumber: text("account_number"), // For mobile banking methods
  walletAddress: text("wallet_address"), // For crypto withdrawals
  bankDetails: text("bank_details"), // For bank transfers
  status: text("status").notNull().default("pending"), // pending, approved, rejected
  statusReason: text("status_reason"), // Reason for approval/rejection
  reference: text("reference"), // Transaction reference/ID
  processedById: integer("processed_by_id").references(() => users.id), // Admin who processed the request
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Live chat messages
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull().references(() => users.id),
  recipientId: integer("recipient_id").references(() => users.id),
  message: text("message").notNull(),
  read: boolean("read").default(false),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Payment methods
export const paymentMethods = pgTable("payment_methods", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'bkash', 'bank', 'crypto'
  name: text("name").notNull(),
  details: json("details"), // Store account numbers, wallet addresses, etc.
  purpose: text("purpose").default("agent_topup").notNull(), // 'agent_topup' or 'player_payment'
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Exchange rates
export const exchangeRates = pgTable("exchange_rates", {
  id: serial("id").primaryKey(),
  fromCurrency: text("from_currency").notNull(),
  toCurrency: text("to_currency").notNull(),
  rate: numeric("rate", { precision: 10, scale: 4 }).notNull(),
  source: text("source").notNull(), // 'manual' or 'api'
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Players
export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  username: text("username").notNull(),
  agentId: integer("agent_id").notNull().references(() => users.id),
  registrationDate: timestamp("registration_date").defaultNow().notNull(),
  firstDepositAmount: numeric("first_deposit_amount", { precision: 10, scale: 2 }).default("0"),
  totalDeposits: numeric("total_deposits", { precision: 10, scale: 2 }).default("0"),
  totalWithdrawals: numeric("total_withdrawals", { precision: 10, scale: 2 }).default("0"),
  isActive: boolean("is_active").default(true),
});

// Player transactions
export const playerTransactions = pgTable("player_transactions", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").notNull().references(() => users.id),
  playerId: text("player_id").notNull(), // Changed to text to allow any ID
  type: text("type").notNull(), // "deposit" or "withdrawal"
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  paymentCode: text("payment_code"),
  status: text("status").notNull().default("pending"), // "pending", "approved", "rejected"
  statusReason: text("status_reason"), // Reason for approval/rejection
  commissionAmount: numeric("commission_amount", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Commissions
export const commissions = pgTable("commissions", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").notNull().references(() => users.id),
  playerId: text("player_id").notNull(), // Changed to text to match playerTransactions
  transactionId: integer("transaction_id").references(() => playerTransactions.id),
  type: text("type").notNull(), // "deposit" or "withdrawal"
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  commission: numeric("commission", { precision: 10, scale: 2 }).notNull(),
  isPaid: boolean("is_paid").default(false),
  paidDate: timestamp("paid_date"),
  scheduledPayout: timestamp("scheduled_payout"), // Date when commission is scheduled to be paid
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Support tickets
export const supportTickets = pgTable("support_tickets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  subject: text("subject").notNull(),
  status: text("status").notNull().default("open"),
  lastActivity: timestamp("last_activity").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Support messages
export const supportMessages = pgTable("support_messages", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").notNull().references(() => supportTickets.id),
  sender: text("sender").notNull(), // "user" or "admin"
  content: text("content").notNull(),
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Remittance Fee Configuration
export const remittanceFees = pgTable("remittance_fees", {
  id: serial("id").primaryKey(),
  channel: text("channel").notNull(), // "npsb_bank", "nagad", "rocket", "bkash"
  feeType: text("fee_type").notNull(), // "flat", "percentage", "hybrid"
  flatFee: numeric("flat_fee", { precision: 10, scale: 2 }).default("0"),
  percentageFee: numeric("percentage_fee", { precision: 10, scale: 2 }).default("0"),
  minAmount: numeric("min_amount", { precision: 10, scale: 2 }),
  maxAmount: numeric("max_amount", { precision: 10, scale: 2 }),
  description: text("description"),
  active: boolean("active").default(true),
  updatedById: integer("updated_by_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Remittance Transactions
export const remittanceTransactions = pgTable("remittance_transactions", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").notNull().references(() => users.id),
  recipientChannel: text("recipient_channel").notNull(), // "npsb_bank", "nagad", "rocket", "bkash"
  recipientName: text("recipient_name"), // Optional field
  recipientAccount: text("recipient_account").notNull(),
  recipientAdditionalInfo: json("recipient_additional_info"),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  feeId: integer("fee_id").references(() => remittanceFees.id),
  feeAmount: numeric("fee_amount", { precision: 10, scale: 2 }).default("0"),
  totalAmount: numeric("total_amount", { precision: 10, scale: 2 }).notNull(),
  transactionNumber: text("transaction_number"), // Assigned upon approval
  status: text("status").default("pending").notNull(), // "pending", "approved", "rejected", "completed"
  statusReason: text("status_reason"),
  notes: text("notes"),
  processedById: integer("processed_by_id").references(() => users.id),
  processedAt: timestamp("processed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Define schemas using drizzle-zod
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
}).extend({
  password: z.string().min(6),
  email: z.string().email(),
  phone: z.string(),
  fullName: z.string(),
});

export const insertTopupTransactionSchema = createInsertSchema(topupTransactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPlayerSchema = createInsertSchema(players).omit({
  id: true,
  registrationDate: true,
});

export const insertPlayerTransactionSchema = createInsertSchema(playerTransactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCommissionSchema = createInsertSchema(commissions).omit({
  id: true,
  createdAt: true,
});

export const insertSupportTicketSchema = createInsertSchema(supportTickets).omit({
  id: true,
  lastActivity: true,
  createdAt: true,
});

export const insertSupportMessageSchema = createInsertSchema(supportMessages).omit({
  id: true,
  createdAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  timestamp: true,
});

export const insertPaymentMethodSchema = createInsertSchema(paymentMethods).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertExchangeRateSchema = createInsertSchema(exchangeRates).omit({
  id: true,
  updatedAt: true,
});

export const insertWithdrawalTransactionSchema = createInsertSchema(withdrawalTransactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  processedById: true,
});

// Remittance schemas
export const insertRemittanceFeeSchema = createInsertSchema(remittanceFees).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  updatedById: true,
});

export const insertRemittanceTransactionSchema = createInsertSchema(remittanceTransactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  processedById: true,
  processedAt: true,
  transactionNumber: true,
  feeId: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type TopupTransaction = typeof topupTransactions.$inferSelect;
export type WithdrawalTransaction = typeof withdrawalTransactions.$inferSelect;
export type InsertWithdrawalTransaction = z.infer<typeof insertWithdrawalTransactionSchema>;
export type Player = typeof players.$inferSelect;
export type PlayerTransaction = typeof playerTransactions.$inferSelect;
export type Commission = typeof commissions.$inferSelect;
export type SupportTicket = typeof supportTickets.$inferSelect;
export type SupportMessage = typeof supportMessages.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type PaymentMethod = typeof paymentMethods.$inferSelect;
export type ExchangeRate = typeof exchangeRates.$inferSelect;
export type RemittanceFee = typeof remittanceFees.$inferSelect;
// Base remittance transaction type
export type RemittanceTransaction = typeof remittanceTransactions.$inferSelect;

// Type for recipient additional info
export type RecipientAdditionalInfo = string | {
  bankName?: string;
  branchName?: string;
  routingNumber?: string;
  accountType?: string;
  [key: string]: any;
};

// Extended remittance transaction type with agent details
export interface ExtendedRemittanceTransaction extends Omit<RemittanceTransaction, 'recipientAdditionalInfo'> {
  agentUsername?: string;
  agentFullName?: string;
  agentEmail?: string;
  agentPhone?: string;
  agentBalance?: string;
  agentRole?: string;
  recipientAdditionalInfo?: RecipientAdditionalInfo;
  feeDetails?: RemittanceFee | null; // Added fee details from associated fee record
}
export type InsertRemittanceFee = z.infer<typeof insertRemittanceFeeSchema>;
export type InsertRemittanceTransaction = z.infer<typeof insertRemittanceTransactionSchema>;
